﻿namespace UFIDA.U9.Cust.HBDY.DipatchOutWhAPISV
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    using UFSoft.UBF.AopFrame;
    using UFSoft.UBF.Util.Context;
    using UFIDA.U9.Cust.HBDY.API.ShipSV;
    using UFIDA.U9.CBO.SCM.Warehouse;
    using UFIDA.U9.Base;
    using UFIDA.U9.ISV.SM.Proxy;
    using UFIDA.U9.ISV.SM;
    using UFIDA.U9.ISV.TransferInISV.Proxy;
    using UFIDA.U9.ISV.TransferInISV;
    using UFIDA.U9.SM.Ship;
    using UFIDA.U9.CBO.Pub.Controller;
    using UFIDA.U9.InvDoc.TransferIn;
    using UFIDA.U9.CBO.SCM.Customer;
    using UFIDA.U9.CBO.SCM.Item;
    using UFIDA.U9.CBO.HR.Operator;

    /// <summary>
    /// DispatchOutWhCarSV partial 
    /// </summary>	
    public partial class DispatchOutWhCarSV
    {
        internal BaseStrategy Select()
        {
            return new DispatchOutWhCarSVImpementStrategy();
        }
    }

    #region  implement strategy
    /// <summary>
    /// Impement Implement
    /// 
    /// </summary>	
    internal partial class DispatchOutWhCarSVImpementStrategy : BaseStrategy
    {
        public DispatchOutWhCarSVImpementStrategy() { }

        public override object Do(object obj)
        {
            DispatchOutWhCarSV bpObj = (DispatchOutWhCarSV)obj;

            List<ShipBackDTO> result = new List<ShipBackDTO>();
            ShipBackDTO resultdto;
            #region 参数校验
            if (bpObj.CarShipLineDTOs == null || bpObj.CarShipLineDTOs.Count == 0)
            {
                resultdto = new ShipBackDTO();
                resultdto.IsSuccess = false;
                resultdto.ErrorInfo = "传入参数不可为空";
                resultdto.Timestamp = DateTime.Now;
                result.Add(resultdto);
                return result;
            }

            List<CarShipLineDTO> shiplist = new List<CarShipLineDTO>();
            List<CarShipLineDTO> transferinlist = new List<CarShipLineDTO>();

            //参数合法校验
            string errormessage = ValidateParamNullOrEmpty(bpObj, ref shiplist, ref transferinlist);

            if (!string.IsNullOrEmpty(errormessage))
            {
                resultdto = new ShipBackDTO();
                resultdto.IsSuccess = false;
                resultdto.ErrorInfo = errormessage + "请检查传入参数";
                resultdto.Timestamp = DateTime.Now;
                result.Add(resultdto);
                return result;
            }
            #endregion

            List<DocKeyDTOData> shipidlist=new List<DocKeyDTOData>();

            List<UFIDA.U9.CBO.Pub.Controller.CommonArchiveDataDTOData> transinidlist=new List<CommonArchiveDataDTOData>();

            #region 创建出货单     
            if (shiplist != null && shiplist.Count > 0)
            {
                try
                {
                    CreateShipSVProxy proxy = new CreateShipSVProxy();
                    proxy.ShipDTOs = GetShipDTOList(shiplist);
                    shipidlist = proxy.Do();
                }
                catch (Exception e)
                {
                    resultdto = new ShipBackDTO();
                    resultdto.IsSuccess = false;
                    resultdto.ErrorInfo = "生成出货单失败：" + e.Message;
                    resultdto.Timestamp = DateTime.Now;
                    result.Add(resultdto);
                    return result;
                }

                if (shipidlist == null || shipidlist.Count <= 0)
                {
                    resultdto = new ShipBackDTO();
                    resultdto.IsSuccess = false;
                    resultdto.ErrorInfo = "生单失败：没有生成出货单";
                    resultdto.Timestamp = DateTime.Now;
                    result.Add(resultdto);
                    return result;
                }

            }
            #endregion
            #region 创建调入单 
            if (transferinlist != null && transferinlist.Count > 0)
            {
                using (UFSoft.UBF.Transactions.UBFTransactionScope trans1 = new UFSoft.UBF.Transactions.UBFTransactionScope(UFSoft.UBF.Transactions.TransactionOption.RequiresNew))
                {

                    try
                    {
                        #region 创建调入单
                        CommonCreateTransferInSVProxy proxy = new CommonCreateTransferInSVProxy();
                        proxy.TransferInDTOList = GetTransferInDTOList(transferinlist);
                        transinidlist = proxy.Do();
                        //}
                        //catch (Exception e)
                        //{
                        //    resultdto = new ShipBackDTO();
                        //    resultdto.IsSuccess = false;
                        //    resultdto.ErrorInfo = "生成调入单失败：" + e.Message;
                        //    resultdto.Timestamp = DateTime.Now;
                        //    result.Add(resultdto);
                        //    return result;
                        //}

                        if (transinidlist == null || transinidlist.Count <= 0)
                        {
                            resultdto = new ShipBackDTO();
                            resultdto.IsSuccess = false;
                            resultdto.ErrorInfo = "生单失败：没有生成调入单";
                            resultdto.Timestamp = DateTime.Now;
                            result.Add(resultdto);
                            return result;
                        }
                        #endregion

                        #region 审核调入单
                        //try
                        //{

                        TransferInBatchApproveSRVProxy approveproxy = new TransferInBatchApproveSRVProxy();
                        approveproxy.DocList = transinidlist;
                        approveproxy.ApprovedBy = Context.LoginUser;
                        approveproxy.ApprovedOn = DateTime.Now;
                        approveproxy.Do();
                        #endregion

                        trans1.Commit();


                    }
                    catch (Exception e)
                    {
                        trans1.Rollback();

                        resultdto = new ShipBackDTO();
                        resultdto.IsSuccess = false;
                        resultdto.ErrorInfo = "生成调入单失败：" + e.Message;
                        resultdto.Timestamp = DateTime.Now;
                        result.Add(resultdto);
                        return result;
                    }


                }
            }
            #endregion

            #region 返回结果

            foreach (DocKeyDTOData shipid in shipidlist)
            {
                Ship ship = Ship.Finder.FindByID(shipid.DocID);
                if (ship != null)
                {
                    resultdto = new ShipBackDTO();
                    resultdto.IsSuccess = true;
                    resultdto.ErrorInfo = "生单出货单成功";
                    resultdto.Timestamp = DateTime.Now;
                    resultdto.ERPDocNo = shipid.DocNO;
                    resultdto.DMSDocNo = ship.DescFlexField.PubDescSeg7;
                    result.Add(resultdto);
                }
            }

            foreach (CommonArchiveDataDTOData transin in transinidlist)
            {
                TransferIn t = TransferIn.Finder.FindByID(transin.ID);
                if (t != null)
                {
                    resultdto = new ShipBackDTO();
                    resultdto.IsSuccess = true;
                    resultdto.ErrorInfo = "生单调入单成功";
                    resultdto.Timestamp = DateTime.Now;
                    resultdto.ERPDocNo = transin.Code;
                    resultdto.DMSDocNo = t.TransInLines[0].DescFlexSegments.PubDescSeg5;
                    result.Add(resultdto);
                }
            }
            #endregion

            return result;

        }
        /// <summary>
        /// 传入参数非空校验
        /// </summary>
        /// <param name="bpObj"></param>
        private string ValidateParamNullOrEmpty(DispatchOutWhCarSV bpObj, ref List<CarShipLineDTO> shiplist, ref List<CarShipLineDTO> transferinlist)
        {

            #region 传入参数校验

            string errormessage = string.Empty;

            foreach (CarShipLineDTO linedto in bpObj.CarShipLineDTOs)
            {

                if (linedto.OrderType == 401103 && !linedto.IsSale)  //如果DMS订单类型为监控车订单，且非实销状态，则调用移库接口，
                {

                    //调出存储地点
                    if (string.IsNullOrEmpty(linedto.WhOut))
                        errormessage += string.Format("[{0}]DMS销售出库单的[调出存储地点({1})]不可为空,", linedto.DMSShipNo,linedto.WhOut);
                    else
                    {
                        Warehouse whout = Warehouse.Finder.Find(string.Format("Org={0} and Code='{1}'", Context.LoginOrg.ID.ToString(), linedto.WhOut));
                        if (whout == null)
                            errormessage += string.Format("[{0}]DMS销售出库单的[调出存储地点({1})]在U9系统中找不到对应的存储地点档案,请同步,", linedto.DMSShipNo,linedto.WhOut);
                    }
                    //调入存储地点
                    if (string.IsNullOrEmpty(linedto.WhIn))
                        errormessage += string.Format("[{0}]DMS销售出库单的[调入存储地点({1})]不可为空,", linedto.DMSShipNo,linedto.WhIn);
                    else
                    {
                        Warehouse whin = Warehouse.Finder.Find(string.Format("Org={0} and Code='{1}'", Context.LoginOrg.ID.ToString(), linedto.WhIn));
                        if (whin == null)
                            errormessage += string.Format("[{0}]DMS销售出库单的[调入存储地点({1})]在U9系统中找不到对应的存储地点档案,请同步,", linedto.DMSShipNo,linedto.WhIn);
                    }

                    transferinlist.Add(linedto);
                }
                else
                {
                    if (linedto.OrderType == 401103 && linedto.IsSale)
                    {

                    }
                    else
                    {
                        if (linedto.VehicleOrChassis <= 0)
                        {
                            errormessage += string.Format("[{0}]DMS销售出库单的[整车或底盘]不可为空,", linedto.DMSShipNo);
                        }
                    }
                    //经销商代码
                    if (string.IsNullOrEmpty(linedto.DealerCode))
                        errormessage += string.Format("[{0}]DMS销售出库单的[经销商代码({1})]不可为空,", linedto.DMSShipNo,linedto.DealerCode);
                    else
                    {
                        Customer customer = Customer.Finder.Find(string.Format("Org={0} and Code='{1}'", Context.LoginOrg.ID.ToString(), linedto.DealerCode));
                        if (customer == null)
                            errormessage += string.Format("[{0}]DMS销售出库单的[经销商代码({1})]在U9系统中找不到对应的客户档案,请同步,", linedto.DMSShipNo,linedto.DealerCode);
                    }

                    shiplist.Add(linedto);

                }

                //物料编号
                if (string.IsNullOrEmpty(linedto.ErpMaterialCode))
                    errormessage += string.Format("[{0}]DMS销售出库单的[ERP料号]不可为空,", linedto.DMSShipNo);
                else
                {
                    ItemMaster item = ItemMaster.Finder.Find(string.Format("Org={0} and Code='{1}'", Context.LoginOrg.ID.ToString(), linedto.ErpMaterialCode));
                    if (item == null)
                        errormessage += string.Format("[{0}]DMS销售出库单的[ERP料号][{1}]在U9系统中找不到对应的料品档案,请同步,", linedto.DMSShipNo, linedto.ErpMaterialCode);
                }

                //数量
                if (linedto.Number <= 0)
                    errormessage += string.Format("[{0}]DMS销售出库单的[数量]必须大于0,", linedto.DMSShipNo);
            }



            return errormessage;
            #endregion


        }
        /// <summary>
        /// 得到出货单dto
        /// </summary>
        /// <param name="bpObj"></param>
        /// <returns></returns>
        private List<ShipDTOForIndustryChainData> GetShipDTOList(List<CarShipLineDTO> shiplist)
        {


            List<ShipDTOForIndustryChainData> list = new List<ShipDTOForIndustryChainData>();

            ShipDTOForIndustryChainData shipdto;
            string opeatorstr = "DMSTESTUSER";

            Dictionary<string, List<CarShipLineDTO>> dic = new Dictionary<string, List<CarShipLineDTO>>();

            foreach (CarShipLineDTO dtoline in shiplist)
            {
                if (!dic.ContainsKey(dtoline.SpitOrderFlag))
                    dic.Add(dtoline.SpitOrderFlag, new List<CarShipLineDTO>());

                dic[dtoline.SpitOrderFlag].Add(dtoline);
            }


            foreach (string key in dic.Keys)
            {
                shipdto = new ShipDTOForIndustryChainData();

                shipdto.CreatedBy = Context.LoginUser;
                shipdto.ModifiedBy = Context.LoginUser;

                string doctypecode = string.Empty;
                //单据类型
                shipdto.DocumentType = new UFIDA.U9.CBO.Pub.Controller.CommonArchiveDataDTOData();        
                if (dic[key][0].OrderType == 401103 && dic[key][0].IsSale) //授信车出库
                    doctypecode = "XM7";
                else 
                {
                    if (dic[key][0].VehicleOrChassis == 400102)  //底盘车出库
                        doctypecode = "XM4";
                    else
                        doctypecode = "XM1";  //整车出库
                }

                shipdto.DocumentType.Code = doctypecode;

                long ConfirmAccording = -1;
                int ConfirmMode = -1;
                long ConfirmTerm = -1;
                long InvoiceAccording = -1;
                long ReceivableTerm = -1;

                ShipDocType doctype = ShipDocType.Finder.Find(string.Format("Org={0} and Code='{1}'", Context.LoginOrg.ID.ToString(), doctypecode));
                if (doctype != null)
                {
                    if (doctype.ConfirmAccordingKey != null)
                        ConfirmAccording = doctype.ConfirmAccording.ID;
                    if (doctype.ConfirmMode.Value >= 0)
                        ConfirmMode = doctype.ConfirmMode.Value;
                    if (doctype.InvoiceAccordingKey != null)
                        InvoiceAccording = doctype.InvoiceAccording.ID;

                }

                string RecTerm = "01";
                Customer customer = Customer.Finder.Find(string.Format("Org={0} and Code='{1}'", Context.LoginOrg.ID.ToString(), dic[key][0].DealerCode));
                if (customer != null)
                {
                    if (customer.ARConfirmTermKey != null)
                        ConfirmTerm = customer.ARConfirmTerm.ID;
                    if (customer.RecervalTermKey != null)
                        ReceivableTerm = customer.RecervalTerm.ID;

                    shipdto.BargainMode = customer.Bargain.Value;
                    shipdto.ShipmentRule = new CommonArchiveDataDTOData();
                    if (customer.ShippmentRuleKey != null)
                    {

                        shipdto.ShipmentRule.Code = customer.ShippmentRule.Code;
                    }
                    else
                        shipdto.ShipmentRule.Code = "C001";

                    if (customer.RecervalTermKey != null)
                        RecTerm = customer.RecervalTerm.Code;

                }
                else
                {
                    shipdto.ShipmentRule.Code = "C001";
                    shipdto.BargainMode = 0;
                }


                shipdto.SrcDocType = 0;

                //立账条件，付款条件，依据  方式
                shipdto.ReceivableTerm = new CommonArchiveDataDTOData();
                if (ReceivableTerm > 0)
                    shipdto.ReceivableTerm.ID = ReceivableTerm;
                else
                    shipdto.ReceivableTerm.Code = "01";

                shipdto.ConfirmTerm = new CommonArchiveDataDTOData();
                if (ConfirmTerm > 0)
                    shipdto.ConfirmTerm.ID = ConfirmTerm;
                else
                    shipdto.ConfirmTerm.Code = "01";

                shipdto.ConfirmAccording = new CommonArchiveDataDTOData();
                shipdto.ConfirmAccording.ID = ConfirmAccording;
                shipdto.ConfirmMode = ConfirmMode < 0 ? 0 : ConfirmMode;
                shipdto.InvoiceAccording = new CommonArchiveDataDTOData();
                shipdto.InvoiceAccording.ID = InvoiceAccording;

                //1.业务员
                shipdto.Seller = new UFIDA.U9.CBO.Pub.Controller.CommonArchiveDataDTOData();
                shipdto.Seller.Code = opeatorstr;
                Operators opeator = Operators.Finder.Find(string.Format("Org={0} and Code='{1}'", Context.LoginOrg.ID.ToString(), opeatorstr));
                if (opeator != null)
                {
                    //3部门
                    shipdto.SaleDept = new UFIDA.U9.CBO.Pub.Controller.CommonArchiveDataDTOData();
                    shipdto.SaleDept.ID = opeator.DeptKey.ID;
                }

                shipdto.CreatedBy = Context.LoginUser;
                shipdto.CreatedOn = DateTime.Now;

                shipdto.OrderBy = new UFIDA.U9.CBO.Pub.Controller.CommonArchiveDataDTOData();
                shipdto.OrderBy.Code = dic[key][0].DealerCode;

                shipdto.AC = new UFIDA.U9.CBO.Pub.Controller.CommonArchiveDataDTOData();
                shipdto.AC.Code = string.IsNullOrEmpty(dic[key][0].Currency) ? "C001" : dic[key][0].Currency;

                shipdto.TC = new UFIDA.U9.CBO.Pub.Controller.CommonArchiveDataDTOData();
                shipdto.TC.Code = string.IsNullOrEmpty(dic[key][0].Currency) ? "C001" : dic[key][0].Currency;

                //移库单号/DMS销售订单
                shipdto.DescFlexField = new UFIDA.U9.Base.FlexField.DescFlexField.DescFlexSegmentsData();
                shipdto.DescFlexField.PubDescSeg5 = dic[key][0].DmsSaleNo;
                shipdto.DescFlexField.PrivateDescSeg1 = dic[key][0].DMSShipNo;


                if (dic[key][0].ShipDate != null && dic[key][0].ShipDate != DateTime.MinValue && dic[key][0].ShipDate > DateTime.Now)
                    shipdto.BusinessDate = dic[key][0].ShipDate;
                else
                    shipdto.BusinessDate = DateTime.Now;

                shipdto.ShipLines = new List<ShipLineDTOForIndustryChainData>();

                ShipLineDTOForIndustryChainData shiplinedto;

                foreach (CarShipLineDTO linedto in dic[key])
                {
                    shiplinedto = new ShipLineDTOForIndustryChainData();

                    //料品
                    shiplinedto.ItemInfo = new UFIDA.U9.CBO.SCM.Item.ItemInfoData();
                    shiplinedto.ItemInfo.ItemCode = linedto.ErpMaterialCode;
                    //shiplinedto.FinallyPriceTC = 1;
                    shiplinedto.ShipQtyTUAmount = linedto.Number;
                    shiplinedto.TotalMoneyTC = linedto.Money;
                    shiplinedto.TotalNetMoneyTC = linedto.Money;

                    shiplinedto.Project = new CommonArchiveDataDTOData();
                    shiplinedto.Project.Code = linedto.DmsSaleNo;


                    //shiplinedto.ReceivableTerm = new CommonArchiveDataDTOData();
                    //shiplinedto.ReceivableTerm.Code = RecTerm;


                    shiplinedto.ConfirmAccording = new CommonArchiveDataDTOData();
                    shiplinedto.ConfirmAccording.ID = ConfirmAccording;
                    shiplinedto.ConfirmMode = ConfirmMode < 0 ? 0 : ConfirmMode;
                    shiplinedto.ConfirmTerm = new CommonArchiveDataDTOData();
                    if (ConfirmTerm > 0)
                        shiplinedto.ConfirmTerm.ID = ConfirmTerm;
                    else
                        shiplinedto.ConfirmTerm.Code = "01";
                    shiplinedto.InvoiceAccording = new CommonArchiveDataDTOData();
                    shiplinedto.InvoiceAccording.ID = InvoiceAccording;
                    shiplinedto.ReceivableTerm = new CommonArchiveDataDTOData();
                    if (ReceivableTerm > 0)
                        shiplinedto.ReceivableTerm.ID = ReceivableTerm;
                    else
                        shiplinedto.ReceivableTerm.Code = "01";

                    //ItemMaster item = ItemMaster.Finder.Find(string.Format("Org={0} and Code='{1}'", Context.LoginOrg.ID.ToString(), linedto.ErpMaterialCode));
                    //2存储地点不可为空
                    //if (item != null && item.InventoryInfo != null)
                    //{
                    shiplinedto.WH = new UFIDA.U9.CBO.Pub.Controller.CommonArchiveDataDTOData();

                    string whcode = string.Empty;
                    if (dic[key][0].OrderType == 401103 && dic[key][0].IsSale) //授信车出库
                        whcode = "0080";//储运整车库
                    else
                    {
                        if (dic[key][0].VehicleOrChassis == 400102)         //底盘车出库
                            whcode = "0090";//储运二类底盘库
                        else
                            whcode = "0080";//储运整车库
                    }
                    shiplinedto.WH.Code = whcode;

                    //shiplinedto.FinallyPriceTC = linedto.RefitMoney;
                    Warehouse whout = Warehouse.Finder.Find(string.Format("Org={0} and Code='{1}'", Context.LoginOrg.ID.ToString(), whcode));
                    if (whout != null && whout.DepositType == DepositTypeEnum.VMI)
                    {
                        shiplinedto.VMI = true;

                        if (whout.SupplierKey != null)
                        {
                            shiplinedto.Supplier = new CommonArchiveDataDTOData();
                            shiplinedto.Supplier.Code = whout.Supplier.Code;
                        }

                    }
                   
                    //}

                    shiplinedto.DescFlexField = new UFIDA.U9.Base.FlexField.DescFlexField.DescFlexSegmentsData();
                    shiplinedto.DescFlexField.PubDescSeg5 = linedto.DmsSaleNo;

                    shiplinedto.Project = new CommonArchiveDataDTOData();
                    shiplinedto.Project.Code = linedto.DmsSaleNo;

                    shiplinedto.DescFlexField.PubDescSeg13 = linedto.EarnestMoney.ToString();
                    //shiplinedto.DescFlexField.PrivateDescSeg9 = linedto.Money.ToString();
                    shiplinedto.DescFlexField.PubDescSeg14 = linedto.ShipMoney <= 0 ? (linedto.Money - linedto.EarnestMoney).ToString() : linedto.ShipMoney.ToString();
                    shiplinedto.DescFlexField.PubDescSeg21 = linedto.Deposit.ToString();
                    shiplinedto.DescFlexField.PubDescSeg12 = linedto.VIN;
                    shipdto.ShipLines.Add(shiplinedto);

                }


                list.Add(shipdto);
            }


            return list;
        }
        /// <summary>
        /// 得到调入单dto
        /// </summary>
        /// <param name="bpObj"></param>
        /// <returns></returns>
        private List<IC_TransferInDTOData> GetTransferInDTOList(List<CarShipLineDTO> transferinlist)
        {
            List<IC_TransferInDTOData> list = new List<IC_TransferInDTOData>();

            IC_TransferInDTOData transindto;

            Dictionary<string, List<CarShipLineDTO>> dic = new Dictionary<string, List<CarShipLineDTO>>();

            foreach (CarShipLineDTO dtoline in transferinlist)
            {
                if (!dic.ContainsKey(dtoline.SpitOrderFlag))
                    dic.Add(dtoline.SpitOrderFlag, new List<CarShipLineDTO>());

                dic[dtoline.SpitOrderFlag].Add(dtoline);
            }


            foreach (string key in dic.Keys)
            {
                transindto = new IC_TransferInDTOData();

                //单据类型
                transindto.TransInDocType = new UFIDA.U9.CBO.Pub.Controller.CommonArchiveDataDTOData();

                transindto.TransInDocType.Code = "CarOutWH";
              

                transindto.CreatedBy = Context.LoginUser;
                transindto.CreatedOn = DateTime.Now;

                transindto.ModifiedBy = Context.LoginUser;
                transindto.ModifiedOn = DateTime.Now;

                transindto.TransInLines = new List<IC_TransInLineDTOData>();

                IC_TransInLineDTOData transinlinedto;
                IC_TransInSubLineDTOData sublinedto;
                foreach (CarShipLineDTO linedto in dic[key])
                {
                    transinlinedto = new IC_TransInLineDTOData();

                    //料品
                    transinlinedto.ItemInfo = new UFIDA.U9.CBO.SCM.Item.ItemInfoData();
                    transinlinedto.ItemInfo.ItemCode = linedto.ErpMaterialCode;

                    transinlinedto.TransInWh = new UFIDA.U9.CBO.Pub.Controller.CommonArchiveDataDTOData();
                    transinlinedto.TransInWh.Code = linedto.WhIn;
                    //存储类型
                    Warehouse whin = Warehouse.Finder.Find(string.Format("Org={0} and Code='{1}'", Context.LoginOrg.ID.ToString(), linedto.WhIn));
                    if (whin != null)
                        transinlinedto.StorageType = whin.StorageType.Value;
                    else
                        transinlinedto.StorageType = 4;

                    transinlinedto.StoreUOMQty = linedto.Number;

                    transinlinedto.CostCurrency = new UFIDA.U9.CBO.Pub.Controller.CommonArchiveDataDTOData();
                    transinlinedto.CostCurrency.Code = linedto.Currency;

                    transinlinedto.Project = new CommonArchiveDataDTOData();
                    transinlinedto.Project.Code = linedto.DmsSaleNo;

                    //移库单号/DMS销售订单
                    transinlinedto.DescFlexSegments = new UFIDA.U9.Base.FlexField.DescFlexField.DescFlexSegmentsData();
                    transinlinedto.DescFlexSegments.PubDescSeg5 = linedto.DmsSaleNo;

                    transinlinedto.TransInSubLines = new List<IC_TransInSubLineDTOData>();
                    sublinedto = new IC_TransInSubLineDTOData();
                    sublinedto.TransOutWh = new UFIDA.U9.CBO.Pub.Controller.CommonArchiveDataDTOData();
                    sublinedto.TransOutWh.Code = linedto.WhOut;
                    //存储类型
                    Warehouse whout = Warehouse.Finder.Find(string.Format("Org={0} and Code='{1}'", Context.LoginOrg.ID.ToString(), linedto.WhOut));
                    if (whout != null)
                        sublinedto.StorageType = whout.StorageType.Value;
                    else
                        sublinedto.StorageType = 4;

                    sublinedto.Project = new CommonArchiveDataDTOData();
                    sublinedto.Project.Code = linedto.DmsSaleNo;

                    transinlinedto.TransInSubLines.Add(sublinedto);
                    transindto.TransInLines.Add(transinlinedto);

                }


                list.Add(transindto);
            }


            return list;
        }
    }

    #endregion


}