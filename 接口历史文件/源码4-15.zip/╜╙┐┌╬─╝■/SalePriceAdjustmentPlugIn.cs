using System;
using System.Collections.Generic;
using System.Text;
using UFIDA.U9.SPR.SalePriceAdjustment;
using UFIDA.U9.Cust.HBDY.DaYunPlugIn.DMS_PI06;
using UFSoft.UBF.Business;

namespace UFIDA.U9.Cust.HBDY.DaYunPlugIn
{
    #region ���۵��۵�����
    public class SalePriceAdjustmentInserted : UFSoft.UBF.Eventing.IEventSubscriber
    {
        public void Notify(params object[] args)
        {

            #region ���¼�������ȡ�õ�ǰҵ��ʵ��

            //���¼�������ȡ�õ�ǰҵ��ʵ��
            if (args == null || args.Length == 0 || !(args[0] is UFSoft.UBF.Business.EntityEvent))
                return;
            BusinessEntity.EntityKey key = ((UFSoft.UBF.Business.EntityEvent)args[0]).EntityKey;
            if (key == null)
                return;
            SalePriceAdjustment SalepriceAdjustment = key.GetEntity() as SalePriceAdjustment;
            bool flag = PubHelper.IsUsedDMSAPI();
            if (flag)
            {
                PI06ImplService service = new PI06ImplService();
                service.Url = PubHelper.GetAddress(service.Url);

                partBaseDto linedto;
                List<partBaseDto> lines = new List<partBaseDto>();

                foreach (SalePriceAdjustLine line in SalepriceAdjustment.SalePriceAdjustLines)
                {

                    linedto = new partBaseDto();

                    linedto.suptCode = string.Empty;
                    if (line.ItemInfo != null && line.ItemInfo.ItemIDKey != null)
                    {
                        linedto.partCode = line.ItemInfo.ItemID.Code;
                        linedto.partName = line.ItemInfo.ItemID.Name;

                        if (line.ItemInfo.ItemID.InventoryUOM != null)
                            linedto.unit = line.ItemInfo.ItemID.InventoryUOM.Name;
                        if (line.ItemInfo.ItemID.PurchaseInfo != null)
                            linedto.miniPack = Convert.ToInt32(line.ItemInfo.ItemID.PurchaseInfo.MinRcvQty);
                    }

                    linedto.salePrice = float.Parse(line.NewPrice.ToString());
                    linedto.unitPrace = linedto.salePrice;
                    linedto.isDanger = "0";
                    linedto.isReturn = "1";
                    linedto.isSale = "1";
                    linedto.isFlag = "1";
                    linedto.isEffective = line.Lapse.ToString();
                    linedto.actionType = 1;

                    lines.Add(linedto);

                }
                try
                {
                    if (lines.Count > 0)
                    {
                        partBaseDto d = service.receive(lines.ToArray());
                        if (d != null && d.flag == 0)
                            throw new ApplicationException(d.errMsg);
                    }

                }
                catch (Exception e)
                {

                    throw new ApplicationException("����DMS�ӿڴ���" + e.Message);
                }
            }
            #endregion
        }
    }
    #endregion
    #region ���۵��۵��޸�
    public class SalePriceAdjustmentUpdated : UFSoft.UBF.Eventing.IEventSubscriber
    {
        public void Notify(params object[] args)
        {

            #region ���¼�������ȡ�õ�ǰҵ��ʵ��

            //���¼�������ȡ�õ�ǰҵ��ʵ��
            if (args == null || args.Length == 0 || !(args[0] is UFSoft.UBF.Business.EntityEvent))
                return;
            BusinessEntity.EntityKey key = ((UFSoft.UBF.Business.EntityEvent)args[0]).EntityKey;
            if (key == null)
                return;
            SalePriceAdjustment SalepriceAdjustment = key.GetEntity() as SalePriceAdjustment;
            bool flag = PubHelper.IsUsedDMSAPI();
            if (flag)
            {
                PI06ImplService service = new PI06ImplService();
                service.Url = PubHelper.GetAddress(service.Url);

                partBaseDto linedto;
                List<partBaseDto> lines = new List<partBaseDto>();

                foreach (SalePriceAdjustLine line in SalepriceAdjustment.SalePriceAdjustLines)
                {
                    if (line.SysState == UFSoft.UBF.PL.Engine.ObjectState.Inserted || (line.SysState == UFSoft.UBF.PL.Engine.ObjectState.Updated && line.NewPrice != line.OriginalData.NewPrice))
                    {

                        linedto = new partBaseDto();

                        linedto.suptCode = string.Empty;
                        if (line.ItemInfo != null && line.ItemInfo.ItemIDKey != null)
                        {
                            linedto.partCode = line.ItemInfo.ItemID.Code;
                            linedto.partName = line.ItemInfo.ItemID.Name;

                            if (line.ItemInfo.ItemID.InventoryUOM != null)
                                linedto.unit = line.ItemInfo.ItemID.InventoryUOM.Name;
                            if (line.ItemInfo.ItemID.PurchaseInfo != null)
                                linedto.miniPack = Convert.ToInt32(line.ItemInfo.ItemID.PurchaseInfo.MinRcvQty);
                        }

                        linedto.salePrice = float.Parse(line.NewPrice.ToString());
                        linedto.unitPrace = linedto.salePrice;
                        linedto.isDanger = "0";
                        linedto.isReturn = "1";
                        linedto.isSale = "1";
                        linedto.isFlag = "1";
                        linedto.isEffective = line.Lapse.ToString();
                        linedto.actionType = 1;

                        lines.Add(linedto);
                    }

                }
                try
                {
                    if (lines.Count > 0)
                    {
                        partBaseDto d = service.receive(lines.ToArray());
                        if (d != null && d.flag == 0)
                            throw new ApplicationException(d.errMsg);
                    }

                }
                catch (Exception e)
                {

                    throw new ApplicationException("����DMS�ӿڴ���" + e.Message);
                }
            }
            #endregion
        }
    }
    #endregion
  
}
