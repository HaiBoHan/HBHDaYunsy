using System;
using System.Collections.Generic;
using System.Text;
using UFSoft.UBF.Business;
using UFIDA.U9.InvTrans.Trans;
using UFIDA.U9.Cust.HBDY.DaYunPlugIn.DMS_PI07;
using UFIDA.U9.PM.Rcv;
using UFIDA.U9.CBO.SCM.Enums;
using UFIDA.U9.PM.Enums;
using UFIDA.U9.SM.RMA;
using UFIDA.U9.SM.Ship;
using UFIDA.U9.InvDoc.MiscShip;

namespace UFIDA.U9.Cust.HBDY.DaYunPlugIn
{
    #region ����춯��ϸ������Inserted
    public class TransLineInserted : UFSoft.UBF.Eventing.IEventSubscriber
    {
        public void Notify(params object[] args)
        {

            #region ���¼�������ȡ�õ�ǰҵ��ʵ��

            //���¼�������ȡ�õ�ǰҵ��ʵ��
            if (args == null || args.Length == 0 || !(args[0] is UFSoft.UBF.Business.EntityEvent))
                return;
            BusinessEntity.EntityKey key = ((UFSoft.UBF.Business.EntityEvent)args[0]).EntityKey;
            if (key == null)
                return;
            TransLine transline = key.GetEntity() as TransLine;
              bool flag = PubHelper.IsUsedDMSAPI();
              if (flag)
              {
                  if (transline.Wh != null && transline.Wh.Code.StartsWith("SHBJ"))
                  {
                      //transline.ItemInfo.ItemID.StockCategory.Code == "26" && 
                      if (transline.DocLine != null && transline.DocLine.EntityType != "UFIDA.U9.InvDoc.PrdEndCheck.PrdEndChkBill" && transline.DocLine.EntityType != "UFIDA.U9.SM.Ship.ShipLine")
                      {
                          string ismiscship=string.Empty;

                          if (transline.DocLine.EntityType == "UFIDA.U9.InvDoc.MiscShip.MiscShipmentL" && transline.DocLine.EntityID > 0)
                          {
                              MiscShipmentL misshipline = MiscShipmentL.Finder.FindByID(transline.DocLine.EntityID);
                              if (misshipline != null)
                                  ismiscship = misshipline.MiscShip.DescFlexField.PubDescSeg5;
                          }
                          if (string.IsNullOrEmpty(ismiscship))
                          {
                              #region ���ÿ��ͬ���ӿ�
                              try
                              {
                                  PI07ImplService service = new PI07ImplService();
                                  service.Url = PubHelper.GetAddress(service.Url);

                                  List<stockDTO> list = new List<stockDTO>();
                                  stockDTO dto = new stockDTO();

                                  dto.itemMaster = transline.ItemInfo.ItemID.Code;
                                  if (transline.SupplierInfo != null && transline.SupplierInfo.Supplier != null)
                                      dto.supplier = transline.SupplierInfo.Supplier.Code;
                                  else
                                  {
                                      if (transline.DocLine.EntityType == "UFIDA.U9.PM.Rcv.RcvLine")
                                      {
                                          RcvLine rcvline = RcvLine.Finder.FindByID(transline.DocLine.EntityID);
                                          if (rcvline != null && rcvline.Receivement.ReceivementType == ReceivementTypeEnum.SaleReturn && rcvline.SrcDocType == RcvSrcDocTypeEnum.RMA && rcvline.SrcDoc != null && rcvline.SrcDoc.SrcDocLine != null && rcvline.SrcDoc.SrcDocLine.EntityID > 0)
                                          {
                                              RMALine rmaline = RMALine.Finder.FindByID(rcvline.SrcDoc.SrcDocLine.EntityID);
                                              if (rmaline != null && rmaline.SrcDocType == RMASrcDocTypeEnum.Ship && rmaline.SrcDocLine != null && rmaline.SrcDocLine.ID > 0)
                                              {
                                                  ShipLine shipline = ShipLine.Finder.FindByID(rmaline.SrcDocLine.ID);
                                                  if (shipline != null && shipline.Supplier != null && shipline.Supplier.Supplier != null)
                                                      dto.supplier = shipline.Supplier.Supplier.Code;
                                              }
                                          }
                                      }
                                  }
                                  dto.number = Convert.ToInt32(transline.StoreUOMQty);
                                  if (transline.LotInfo != null)
                                      dto.lot = transline.LotInfo.LotCode;
                                  //if (transline.WhKey != null)
                                  //dto.WH = transline.Wh.Code;
                                  dto.WH = "SHBJ";
                                  if (transline.Direction == UFIDA.U9.CBO.SCM.Enums.TransDirectionEnum.Rcv)
                                      dto.actionType = 0;
                                  else
                                      dto.actionType = 1;

                                  list.Add(dto);

                                  stockDTO[] dtolist = service.receive(list.ToArray());
                                  if (dtolist != null && dtolist.Length > 0 && dtolist[0].flag == 0)
                                      throw new ApplicationException(dtolist[0].errMsg);

                              }
                              catch (Exception e)
                              {

                                  throw new ApplicationException("����DMS�ӿڴ���" + e.Message);
                              }
                              #endregion

                          }
                      }
                  }
              }
            #endregion
        }
    }
    #endregion
    #region ����춯��ϸ������Deleted
    public class TransLineDeleted : UFSoft.UBF.Eventing.IEventSubscriber
    {
        public void Notify(params object[] args)
        {

            #region ���¼�������ȡ�õ�ǰҵ��ʵ��

            //���¼�������ȡ�õ�ǰҵ��ʵ��
            if (args == null || args.Length == 0 || !(args[0] is UFSoft.UBF.Business.EntityEvent))
                return;
            BusinessEntity.EntityKey key = ((UFSoft.UBF.Business.EntityEvent)args[0]).EntityKey;
            if (key == null)
                return;
            TransLine transline = key.GetEntity() as TransLine;
            bool flag = PubHelper.IsUsedDMSAPI();
            if (flag)
            {
                if (transline.Wh != null && transline.Wh.Code.StartsWith("SHBJ"))
                {
                    //transline.ItemInfo.ItemID.StockCategory.Code == "26" && 
                    if (transline.DocLine != null && transline.DocLine.EntityType != "UFIDA.U9.InvDoc.PrdEndCheck.PrdEndChkBill" && transline.DocLine.EntityType != "UFIDA.U9.SM.Ship.ShipLine")
                    {
                        string ismiscship = string.Empty;

                        if (transline.DocLine.EntityType == "UFIDA.U9.InvDoc.MiscShip.MiscShipmentL" && transline.DocLine.EntityID > 0)
                        {
                            MiscShipmentL misshipline = MiscShipmentL.Finder.FindByID(transline.DocLine.EntityID);
                            if (misshipline != null)
                                ismiscship = misshipline.MiscShip.DescFlexField.PubDescSeg5;
                        }
                        if (string.IsNullOrEmpty(ismiscship))
                        {
                            #region ���ÿ��ͬ���ӿ�
                            try
                            {
                                PI07ImplService service = new PI07ImplService();
                                service.Url = PubHelper.GetAddress(service.Url);

                                List<stockDTO> list = new List<stockDTO>();
                                stockDTO dto = new stockDTO();

                                dto.itemMaster = transline.ItemInfo.ItemID.Code;
                                if (transline.SupplierInfo != null && transline.SupplierInfo.Supplier != null)
                                    dto.supplier = transline.SupplierInfo.Supplier.Code;
                                else
                                {
                                    if (transline.DocLine.EntityType == "UFIDA.U9.PM.Rcv.RcvLine")
                                    {
                                        RcvLine rcvline = RcvLine.Finder.FindByID(transline.DocLine.EntityID);
                                        if (rcvline != null && rcvline.Receivement.ReceivementType == ReceivementTypeEnum.SaleReturn && rcvline.SrcDocType == RcvSrcDocTypeEnum.RMA && rcvline.SrcDoc != null && rcvline.SrcDoc.SrcDocLine != null && rcvline.SrcDoc.SrcDocLine.EntityID > 0)
                                        {
                                            RMALine rmaline = RMALine.Finder.FindByID(rcvline.SrcDoc.SrcDocLine.EntityID);
                                            if (rmaline != null && rmaline.SrcDocType == RMASrcDocTypeEnum.Ship && rmaline.SrcDocLine != null && rmaline.SrcDocLine.ID > 0)
                                            {
                                                ShipLine shipline = ShipLine.Finder.FindByID(rmaline.SrcDocLine.ID);
                                                if (shipline != null && shipline.Supplier != null && shipline.Supplier.Supplier != null)
                                                    dto.supplier = shipline.Supplier.Supplier.Code;
                                            }
                                        }
                                    }
                                }
                                dto.number = Convert.ToInt32(transline.StoreUOMQty);
                                if (transline.LotInfo != null)
                                    dto.lot = transline.LotInfo.LotCode;
                                //if (transline.WhKey != null)
                                //dto.WH = transline.Wh.Code;
                                dto.WH = "SHBJ";
                                if (transline.Direction == UFIDA.U9.CBO.SCM.Enums.TransDirectionEnum.Rcv)
                                    dto.actionType = 1;
                                else
                                    dto.actionType = 0;

                                list.Add(dto);

                                stockDTO[] dtolist = service.receive(list.ToArray());
                                if (dtolist != null && dtolist.Length > 0 && dtolist[0].flag == 0)
                                    throw new ApplicationException(dtolist[0].errMsg);

                            }
                            catch (Exception e)
                            {

                                throw new ApplicationException("����DMS�ӿڴ���" + e.Message);
                            }

                            #endregion
                        }
                    }
                }
            }
            #endregion
        }
    }
    #endregion
}
