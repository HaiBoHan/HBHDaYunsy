﻿namespace UFIDA.U9.Cust.HBDY.API.RMASV
{
	using System;
	using System.Collections.Generic;
	using System.Text; 
	using UFSoft.UBF.AopFrame;	
	using UFSoft.UBF.Util.Context;
    using UFIDA.U9.Cust.HBDY.API.ShipSV;
    using UFIDA.U9.CBO.SCM.Customer;
    using UFIDA.U9.Base;
    using UFIDA.U9.CBO.SCM.Item;
    using UFIDA.U9.ISV.SM.Proxy;
    using UFIDA.U9.ISV.SM;
    using UFIDA.U9.SM.RMA;
    using UFIDA.U9.Base.Currency;
    using UFSoft.UBF.Business;
    using UFIDA.U9.CBO.SCM.Warehouse;

	/// <summary>
	/// CreateRMASV partial 
	/// </summary>	
	public partial class CreateRMASV 
	{	
		internal BaseStrategy Select()
		{
			return new CreateRMASVImpementStrategy();	
		}		
	}
	
	#region  implement strategy	
	/// <summary>
	/// Impement Implement
	/// 
	/// </summary>	
	internal partial class CreateRMASVImpementStrategy : BaseStrategy
	{
		public CreateRMASVImpementStrategy() { }

		public override object Do(object obj)
		{						
			CreateRMASV bpObj = (CreateRMASV)obj;
            List<ShipBackDTO> result = new List<ShipBackDTO>();
            ShipBackDTO resultdto;

            try
            {
                #region 参数校验
                if (bpObj.RMALineDTOs == null || bpObj.RMALineDTOs.Count == 0)
                {
                    resultdto = new ShipBackDTO();
                    resultdto.IsSuccess = false;
                    resultdto.ErrorInfo = "传入参数不可为空";
                    resultdto.Timestamp = DateTime.Now;
                    result.Add(resultdto);
                    return result;
                }
                //参数合法校验
                string errormessage = ValidateParamNullOrEmpty(bpObj);

                if (!string.IsNullOrEmpty(errormessage))
                {
                    resultdto = new ShipBackDTO();
                    resultdto.IsSuccess = false;
                    resultdto.ErrorInfo = errormessage + "请检查传入参数";
                    resultdto.Timestamp = DateTime.Now;
                    result.Add(resultdto);
                    return result;
                }
                #endregion
                List<DocKeyDTOData> rmaidlist;

                #region 创建退回处理单
                try
                {

                    CreateRMASRVProxy proxy = new CreateRMASRVProxy();
                    proxy.RMADTOs = GetRMADTOList(bpObj);

                    proxy.ContextDTO = new UFIDA.U9.CBO.Pub.Controller.ContextDTOData();
                    proxy.ContextDTO.OrgID = Context.LoginOrg.ID;
                    proxy.ContextDTO.OrgCode = Context.LoginOrg.Code;
                    proxy.ContextDTO.EntCode = bpObj.RMALineDTOs[0].EnterpriseCode;
                    proxy.ContextDTO.UserID = long.Parse(Context.LoginUserID);
                    proxy.ContextDTO.UserCode = Context.LoginUser;
                    proxy.ContextDTO.CultureName = Context.LoginLanguageCode;

                    rmaidlist = proxy.Do();

                }
                catch (Exception e)
                {
                    resultdto = new ShipBackDTO();
                    resultdto.IsSuccess = false;
                    resultdto.ErrorInfo = "生单失败：" + e.Message;
                    resultdto.Timestamp = DateTime.Now;
                    result.Add(resultdto);
                    return result;
                }

                if (rmaidlist == null || rmaidlist.Count <= 0)
                {
                    resultdto = new ShipBackDTO();
                    resultdto.IsSuccess = false;
                    resultdto.ErrorInfo = "生单失败：没有生成退回处理单";
                    resultdto.Timestamp = DateTime.Now;
                    result.Add(resultdto);
                    return result;
                }
                #endregion

                foreach (DocKeyDTOData rmaid in rmaidlist)
                {

                    resultdto = new ShipBackDTO();
                    resultdto.IsSuccess = true;
                    resultdto.ErrorInfo = "生单成功";
                    resultdto.Timestamp = DateTime.Now;
                    resultdto.ERPDocNo = rmaid.DocNO;


                    result.Add(resultdto);
                }

                return result;
            }
            catch (Exception e)
            {

                resultdto = new ShipBackDTO();
                resultdto.IsSuccess = false;
                resultdto.ErrorInfo = e.Message;
                resultdto.Timestamp = DateTime.Now;
                result.Add(resultdto);
                return result;
            }
           

        }
        /// <summary>
        /// 传入参数非空校验
        /// </summary>
        /// <param name="bpObj"></param>
        private string ValidateParamNullOrEmpty(CreateRMASV bpObj)
        {

            #region 传入参数校验

            string errormessage = string.Empty;
         
     
                foreach (RMALineDTO linedto in bpObj.RMALineDTOs)
                {
                    //经销商代码
                    if (string.IsNullOrEmpty(linedto.DealerCode))
                        errormessage += string.Format("[{0}]DMS销售出库单的[经销商代码]不可为空,", linedto.DMSShipNo);
                    else
                    {
                        Customer customer = Customer.Finder.Find(string.Format("Org={0} and Code='{1}'", Context.LoginOrg.ID.ToString(), linedto.DealerCode));
                        if (customer == null)
                            errormessage += string.Format("[{0}]DMS销售出库单的[经销商代码({1})]在U9系统中找不到对应的客户档案,请同步,", linedto.DMSShipNo,linedto.DealerCode);
                    }

                    //物料编号
                    if (string.IsNullOrEmpty(linedto.ErpMaterialCode))
                        errormessage += string.Format("[{0}]DMS销售出库单的参数RMALineDTOs的[ERP料号]不可为空,", linedto.DMSShipNo);
                    else
                    {
                        ItemMaster item = ItemMaster.Finder.Find(string.Format("Org={0} and Code='{1}'", Context.LoginOrg.ID.ToString(), linedto.ErpMaterialCode));
                        if (item == null)
                            errormessage += string.Format("[{0}]DMS销售出库单的参数RMALineDTOs的[ERP料号][{1}]在U9系统中找不到对应的料品档案,请同步,", linedto.DMSShipNo, linedto.ErpMaterialCode);
                    }

                    //调出存储地点
                    if (string.IsNullOrEmpty(linedto.WHIn))
                        errormessage += string.Format("[{0}]DMS销售出库单的参数RMALineDTOs的[存储地点]不可为空,", linedto.DMSShipNo);
                    else
                    {
                        Warehouse whout = Warehouse.Finder.Find(string.Format("Org={0} and Code='{1}'", Context.LoginOrg.ID.ToString(), linedto.WHIn));
                        if (whout == null)
                            errormessage += string.Format("[{0}]DMS销售出库单的参数RMALineDTOs的[存储地点({1})]在U9系统中找不到对应的存储地点档案,请同步,", linedto.DMSShipNo,linedto.WHIn);
                    }
                    //数量
                    if (linedto.Number <= 0)
                        errormessage += string.Format("[{0}]DMS销售出库单的参数RMALineDTOs的[退回数量]必须大于0,", linedto.DMSShipNo);
                }


            return errormessage;
            #endregion


        }
        /// <summary>
        /// 得到调入单dto
        /// </summary>
        /// <param name="bpObj"></param>
        /// <returns></returns>
        private List<UFIDA.U9.ISV.SM.RMADTOData> GetRMADTOList(CreateRMASV bpObj)
        {
            List<UFIDA.U9.ISV.SM.RMADTOData> list = new List<UFIDA.U9.ISV.SM.RMADTOData>();

            UFIDA.U9.ISV.SM.RMADTOData rmadto;
            string opeatorstr = "DMSTESTUSER";

            Dictionary<string, List<RMALineDTO>> dic = new Dictionary<string, List<RMALineDTO>>();

            foreach (RMALineDTO dtoline in bpObj.RMALineDTOs)
            {
                if (!dic.ContainsKey(dtoline.SpitOrderFlag))
                    dic.Add(dtoline.SpitOrderFlag, new List<RMALineDTO>());

                dic[dtoline.SpitOrderFlag].Add(dtoline);
            }

            foreach (string key in dic.Keys)
            {
                rmadto = new UFIDA.U9.ISV.SM.RMADTOData();

                RMALineDTO dto = dic[key][0];

                //单据类型
                rmadto.DocumentTypeDTO = new UFIDA.U9.Base.DTOs.IDCodeNameDTOData();
                rmadto.DocumentTypeDTO.Code = "H0001";
                rmadto.KeepAccountsPeriodDTO = new UFIDA.U9.Base.DTOs.IDCodeNameDTOData();
                //shipdto.SrcDocType = 0;


                RMADocType doctype = RMADocType.Finder.Find(string.Format("Org={0} and Code='{1}'", Context.LoginOrg.ID.ToString(), "H0001"));
                if (doctype != null)
                {
                    if (doctype.AccountAccordingKey != null)
                    {
                        rmadto.ConfirmAccordingDTO = new UFIDA.U9.Base.DTOs.IDCodeNameDTOData();
                        rmadto.ConfirmAccordingDTO.Code = doctype.AccountAccording.Code;
                    }
                    if (doctype.BillingMode.Value >= 0)
                        rmadto.BillingMode = doctype.BillingMode.Value;
                    else
                        rmadto.BillingMode = 0;

                    if (doctype.InvoiceAccordingKey != null)
                    {
                        rmadto.InvoiceAccordingDTO = new UFIDA.U9.Base.DTOs.IDCodeNameDTOData();
                        rmadto.InvoiceAccordingDTO.Code = doctype.InvoiceAccording.Code;
                    }

                }
                else
                {
                   
                    rmadto.BillingMode = 0;
                }

                rmadto.AccrueTermDTO = new UFIDA.U9.Base.DTOs.IDCodeNameDTOData();
                rmadto.AccrueTermDTO.Code = "01";

                rmadto.CustomerDTO = new UFIDA.U9.Base.DTOs.IDCodeNameDTOData();
                rmadto.CustomerDTO.Code = dto.DealerCode;

                rmadto.ACDTO = new UFIDA.U9.Base.DTOs.IDCodeNameDTOData();
                rmadto.ACDTO.Code = string.IsNullOrEmpty(dto.Currency) ? "C001" : dto.Currency;

                rmadto.TCDTO = new UFIDA.U9.Base.DTOs.IDCodeNameDTOData();
                rmadto.TCDTO.Code = string.IsNullOrEmpty(dto.Currency) ? "C001" : dto.Currency;

                //移库单号/DMS销售订单
                rmadto.DescFlexField = new UFIDA.U9.Base.FlexField.DescFlexField.DescFlexSegmentsData();
                rmadto.DescFlexField.PubDescSeg5 = dto.DmsSaleNo;
                rmadto.DescFlexField.PrivateDescSeg1 = dto.DMSShipNo;
                rmadto.DescFlexField.PubDescSeg12 = dto.VIN;

                rmadto.DescFlexField.PubDescSeg13 = dto.EarnestMoney.ToString();
                rmadto.DescFlexField.PubDescSeg14 = dto.ShipMoney <= 0 ? (dto.Money - dto.EarnestMoney).ToString() : dto.ShipMoney.ToString();
                rmadto.DescFlexField.PubDescSeg21 = dto.Deposit.ToString();

                if (dto.ShipDate != null && dto.ShipDate != DateTime.MinValue && dto.ShipDate > DateTime.Now)
                    rmadto.BusinessDate = dto.ShipDate;
                else
                    rmadto.BusinessDate = DateTime.Now;

                rmadto.RMALines = new List<UFIDA.U9.ISV.SM.RMALineDTOData>();
                
                UFIDA.U9.ISV.SM.RMALineDTOData rmalinedto;

                foreach (RMALineDTO linedto in dic[key])
                {
                    rmalinedto = new UFIDA.U9.ISV.SM.RMALineDTOData();

                    //料品
                    rmalinedto.ItemInfoDTO = new UFIDA.U9.Base.DTOs.IDCodeNameDTOData();
                    rmalinedto.ItemInfoDTO.Code = linedto.ErpMaterialCode;
                    
                    rmalinedto.ApplyQtyTU1 = linedto.Number;
                    rmalinedto.RtnQtyTU1 = linedto.Number;
                    rmalinedto.RtnQtyPU = linedto.Number;
                    rmalinedto.ApplyMoneyTC = linedto.Money;

                    rmalinedto.ProjectDTO = new UFIDA.U9.Base.DTOs.IDCodeNameDTOData();
                    rmalinedto.ProjectDTO.Code = linedto.DmsSaleNo;

                    rmalinedto.WarehouseDTO = new UFIDA.U9.Base.DTOs.IDCodeNameDTOData();
                    rmalinedto.WarehouseDTO.Code = linedto.WHIn;

                    rmadto.RMALines.Add(rmalinedto);

                }


                list.Add(rmadto);
            }


            return list;
        }
    }

    #endregion


}