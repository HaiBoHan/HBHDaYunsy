using System;
using System.Collections.Generic;
using System.Text;
using UFSoft.UBF.Business;
using UFIDA.U9.CBO.SCM.Supplier;
using UFIDA.U9.SPR.SalePriceList;
using UFIDA.U9.Base;
using UFIDA.U9.Cust.HBDY.DaYunPlugIn.DMS_PI06;

namespace UFIDA.U9.Cust.HBDY.DaYunPlugIn
{
    #region ��Ӧ��-��Ʒ���� ����
    public class SupplierItemInserted : UFSoft.UBF.Eventing.IEventSubscriber
    {
        public void Notify(params object[] args)
        {

            #region ���¼�������ȡ�õ�ǰҵ��ʵ��

            //���¼�������ȡ�õ�ǰҵ��ʵ��
            if (args == null || args.Length == 0 || !(args[0] is UFSoft.UBF.Business.EntityEvent))
                return;
            BusinessEntity.EntityKey key = ((UFSoft.UBF.Business.EntityEvent)args[0]).EntityKey;
            if (key == null)
                return;
            SupplierItem supplierItem = key.GetEntity() as SupplierItem;

            if (supplierItem.ItemInfo.ItemID.StockCategory.Code == "26")   //���������Ϊ���ۺ������
            {
                try
                {
                    PI06ImplService service = new PI06ImplService();
                    service.Url = PubHelper.GetAddress(service.Url);

                    partBaseDto linedto = new partBaseDto();
                    List<partBaseDto> lines = new List<partBaseDto>();

                    //if (supplierItem.ItemInfo.ItemID.PurchaseInfo != null && supplierItem.ItemInfo.ItemID.PurchaseInfo.SupplierKey != null)
                    //    linedto.suptCode = supplierItem.ItemInfo.ItemID.PurchaseInfo.Supplier.Code;

                    if (supplierItem.SupplierInfo != null && supplierItem.SupplierInfo.SupplierKey != null)
                        linedto.suptCode = supplierItem.SupplierInfo.Supplier.Code;
                    if (supplierItem.ItemInfo != null && supplierItem.ItemInfo.ItemIDKey != null)
                    {
                        linedto.partCode = supplierItem.ItemInfo.ItemID.Code;
                        linedto.partName = supplierItem.ItemInfo.ItemID.Name;
                    }
                    if (supplierItem.ItemInfo.ItemID.InventoryUOM != null)
                        linedto.unit = supplierItem.ItemInfo.ItemID.InventoryUOM.Name;
                    if (supplierItem.ItemInfo.ItemID.PurchaseInfo != null)
                        linedto.miniPack = Convert.ToInt32(supplierItem.ItemInfo.ItemID.PurchaseInfo.MinRcvQty);
                    linedto.isFlag = "2";

                    SalePriceLine line = SalePriceLine.Finder.Find(string.Format("SalePriceList.Org={0} and ItemInfo.ItemID={1} and Active=1 and '{2}' between FromDate and ToDate", Context.LoginOrg.ID.ToString(), supplierItem.ItemInfo.ItemID.ID.ToString(), DateTime.Now.ToString()));
                    if (line != null)
                    {
                        linedto.salePrice = float.Parse(line.Price.ToString());
                        linedto.unitPrace = linedto.salePrice;
                    }
                    else
                    {
                        linedto.salePrice = 0;
                        linedto.unitPrace = 0;
                    }
                    linedto.isDanger = "0";
                    linedto.isReturn = "1";
                    linedto.isSale = "1";


                    linedto.isEffective = supplierItem.Effective.IsEffective.ToString();
                    linedto.actionType = 1;

                    lines.Add(linedto);
                    partBaseDto d = service.receive(lines.ToArray());
                    if (d != null && d.flag == 0)
                        throw new ApplicationException(d.errMsg);
                }
                catch (Exception e)
                {

                    throw new ApplicationException("����DMS�ӿڴ���" + e.Message);
                }

            }


            #endregion
        }
    }
    #endregion
    #region ��Ӧ��-��Ʒ���� ɾ��
    public class SupplierItemDeleted : UFSoft.UBF.Eventing.IEventSubscriber
    {
        public void Notify(params object[] args)
        {

            #region ���¼�������ȡ�õ�ǰҵ��ʵ��

            //���¼�������ȡ�õ�ǰҵ��ʵ��
            if (args == null || args.Length == 0 || !(args[0] is UFSoft.UBF.Business.EntityEvent))
                return;
            BusinessEntity.EntityKey key = ((UFSoft.UBF.Business.EntityEvent)args[0]).EntityKey;
            if (key == null)
                return;
            SupplierItem supplierItem = key.GetEntity() as SupplierItem;

            if (supplierItem.ItemInfo.ItemID.StockCategory.Code == "26")   //���������Ϊ���ۺ������
            {
                try
                {
                    PI06ImplService service = new PI06ImplService();
                    service.Url = PubHelper.GetAddress(service.Url);

                    partBaseDto linedto = new partBaseDto();
                    List<partBaseDto> lines = new List<partBaseDto>();

                    //if (supplierItem.ItemInfo.ItemID.PurchaseInfo != null && supplierItem.ItemInfo.ItemID.PurchaseInfo.SupplierKey != null)
                    //    linedto.suptCode = supplierItem.ItemInfo.ItemID.PurchaseInfo.Supplier.Code;

                    if (supplierItem.SupplierInfo != null && supplierItem.SupplierInfo.SupplierKey != null)
                        linedto.suptCode = supplierItem.SupplierInfo.Supplier.Code;
                    if (supplierItem.ItemInfo != null && supplierItem.ItemInfo.ItemIDKey != null)
                    {
                        linedto.partCode = supplierItem.ItemInfo.ItemID.Code;
                        linedto.partName = supplierItem.ItemInfo.ItemID.Name;
                    }
                    if (supplierItem.ItemInfo.ItemID.InventoryUOM != null)
                        linedto.unit = supplierItem.ItemInfo.ItemID.InventoryUOM.Name;
                    if (supplierItem.ItemInfo.ItemID.PurchaseInfo != null)
                        linedto.miniPack = Convert.ToInt32(supplierItem.ItemInfo.ItemID.PurchaseInfo.MinRcvQty);


                    SalePriceLine line = SalePriceLine.Finder.Find(string.Format("SalePriceList.Org={0} and ItemInfo.ItemID={1} and Active=1 and '{2}' between FromDate and ToDate", Context.LoginOrg.ID.ToString(), supplierItem.ItemInfo.ItemID.ID.ToString(), DateTime.Now.ToString()));
                    if (line != null)
                    {
                        linedto.salePrice = float.Parse(line.Price.ToString());
                        linedto.unitPrace = linedto.salePrice;
                    }
                    else
                    {
                        linedto.salePrice = 0;
                        linedto.unitPrace = 0;
                    }
                    linedto.isFlag = "2";
                    linedto.isDanger = "0";
                    linedto.isReturn = "1";
                    linedto.isSale = "1";


                    linedto.isEffective = supplierItem.Effective.IsEffective.ToString();
                    linedto.actionType = 3;

                    lines.Add(linedto);
                    partBaseDto d = service.receive(lines.ToArray());
                    if (d != null && d.flag == 0)
                        throw new ApplicationException(d.errMsg);
                }
                catch (Exception e)
                {

                    throw new ApplicationException("����DMS�ӿڴ���" + e.Message);
                }

            }

            #endregion
        }
    }
    #endregion
    #region ��Ӧ��-��Ʒ���� �޸�
    public class SupplierItemUpdated : UFSoft.UBF.Eventing.IEventSubscriber
    {
        public void Notify(params object[] args)
        {

            #region ���¼�������ȡ�õ�ǰҵ��ʵ��

            //���¼�������ȡ�õ�ǰҵ��ʵ��
            if (args == null || args.Length == 0 || !(args[0] is UFSoft.UBF.Business.EntityEvent))
                return;
            BusinessEntity.EntityKey key = ((UFSoft.UBF.Business.EntityEvent)args[0]).EntityKey;
            if (key == null)
                return;
            SupplierItem supplierItem = key.GetEntity() as SupplierItem;
            if (supplierItem.OriginalData.ItemInfo.ItemID != supplierItem.ItemInfo.ItemID || supplierItem.OriginalData.SupplierInfo.SupplierKey != supplierItem.SupplierInfo.SupplierKey)
            {
                PI06ImplService service = new PI06ImplService();
                service.Url = PubHelper.GetAddress(service.Url);

                partBaseDto linedto;
                List<partBaseDto> lines = new List<partBaseDto>();
                #region ɾ��
                if (supplierItem.OriginalData.ItemInfo.ItemID.StockCategory.Code == "26")
                {
                    linedto = new partBaseDto();

                    if (supplierItem.OriginalData.SupplierInfo != null && supplierItem.OriginalData.SupplierInfo.SupplierKey != null)
                        linedto.suptCode = supplierItem.OriginalData.SupplierInfo.Supplier.Code;
                    if (supplierItem.OriginalData.ItemInfo != null && supplierItem.OriginalData.ItemInfo.ItemIDKey != null)
                    {
                        linedto.partCode = supplierItem.OriginalData.ItemInfo.ItemID.Code;
                        linedto.partName = supplierItem.OriginalData.ItemInfo.ItemID.Name;
                    }
                    if (supplierItem.OriginalData.ItemInfo.ItemID.InventoryUOM != null)
                        linedto.unit = supplierItem.OriginalData.ItemInfo.ItemID.InventoryUOM.Name;
                    if (supplierItem.OriginalData.ItemInfo.ItemID.PurchaseInfo != null)
                        linedto.miniPack = Convert.ToInt32(supplierItem.OriginalData.ItemInfo.ItemID.PurchaseInfo.MinRcvQty);


                    SalePriceLine line = SalePriceLine.Finder.Find(string.Format("SalePriceList.Org={0} and ItemInfo.ItemID={1} and Active=1 and '{2}' between FromDate and ToDate", Context.LoginOrg.ID.ToString(), supplierItem.OriginalData.ItemInfo.ItemID.ID.ToString(), DateTime.Now.ToString()));
                    if (line != null)
                    {
                        linedto.salePrice = float.Parse(line.Price.ToString());
                        linedto.unitPrace = linedto.salePrice;
                    }
                    else
                    {
                        linedto.salePrice = 0;
                        linedto.unitPrace = 0;
                    }
                    linedto.isFlag = "2";
                    linedto.isDanger = "0";
                    linedto.isReturn = "1";
                    linedto.isSale = "1";


                    linedto.isEffective = supplierItem.OriginalData.Effective.IsEffective.ToString();
                    linedto.actionType = 3;

                    lines.Add(linedto);
                }
                #endregion
                #region ����
                if (supplierItem.ItemInfo.ItemID.StockCategory.Code == "26")   //���������Ϊ���ۺ������
                {

                    linedto = new partBaseDto();

                    if (supplierItem.SupplierInfo != null && supplierItem.SupplierInfo.SupplierKey != null)
                        linedto.suptCode = supplierItem.SupplierInfo.Supplier.Code;
                    if (supplierItem.ItemInfo != null && supplierItem.ItemInfo.ItemIDKey != null)
                    {
                        linedto.partCode = supplierItem.ItemInfo.ItemID.Code;
                        linedto.partName = supplierItem.ItemInfo.ItemID.Name;
                    }
                    if (supplierItem.ItemInfo.ItemID.InventoryUOM != null)
                        linedto.unit = supplierItem.ItemInfo.ItemID.InventoryUOM.Name;
                    if (supplierItem.ItemInfo.ItemID.PurchaseInfo != null)
                        linedto.miniPack = Convert.ToInt32(supplierItem.ItemInfo.ItemID.PurchaseInfo.MinRcvQty);


                    SalePriceLine line = SalePriceLine.Finder.Find(string.Format("SalePriceList.Org={0} and ItemInfo.ItemID={1} and Active=1 and '{2}' between FromDate and ToDate", Context.LoginOrg.ID.ToString(), supplierItem.ItemInfo.ItemID.ID.ToString(), DateTime.Now.ToString()));
                    if (line != null)
                    {
                        linedto.salePrice = float.Parse(line.Price.ToString());
                        linedto.unitPrace = linedto.salePrice;
                    }
                    else
                    {
                        linedto.salePrice = 0;
                        linedto.unitPrace = 0;
                    }
                    linedto.isFlag = "2";
                    linedto.isDanger = "0";
                    linedto.isReturn = "1";
                    linedto.isSale = "1";


                    linedto.isEffective = supplierItem.Effective.IsEffective.ToString();
                    linedto.actionType = 1;

                    lines.Add(linedto);

                } 
            #endregion
                try
                {
                    partBaseDto d = service.receive(lines.ToArray());
                    if (d != null && d.flag == 0)
                        throw new ApplicationException(d.errMsg);
                }
                catch (Exception e)
                {

                    throw new ApplicationException("����DMS�ӿڴ���" + e.Message);
                }
               
            }
            #endregion
        }
    }
    #endregion
}
