using System;
using System.Collections.Generic;
using System.Text;
using UFSoft.UBF.Business;
using UFIDA.U9.AR.ARBill;
using UFIDA.U9.CBO.FI.Enums;
using UFIDA.U9.SM.Ship;
using UFIDA.U9.Cust.HBDY.DaYunPlugIn.DMS_SI05;
using UFIDA.U9.SM.RMA;

namespace UFIDA.U9.Cust.HBDY.DaYunPlugIn
{
    #region Ӧ�յ�Updated
    public class ARBillHeadUpdated : UFSoft.UBF.Eventing.IEventSubscriber
    {
        public void Notify(params object[] args)
        {

            #region ���¼�������ȡ�õ�ǰҵ��ʵ��

            //���¼�������ȡ�õ�ǰҵ��ʵ��
            if (args == null || args.Length == 0 || !(args[0] is UFSoft.UBF.Business.EntityEvent))
                return;
            BusinessEntity.EntityKey key = ((UFSoft.UBF.Business.EntityEvent)args[0]).EntityKey;
            if (key == null)
                return;
            ARBillHead ARbillhead = key.GetEntity() as ARBillHead;
            //Ӧ�����ʱ�����ۿ���Ϣ���á��ʽ�ͬ���ӿڡ���DMS
              bool flag = PubHelper.IsUsedDMSAPI();
              if (flag)
              {
                  if (ARbillhead.OriginalData.DocStatus == BillStatusEnum.Approving && ARbillhead.DocStatus == BillStatusEnum.Approved)
                  {
                      SI05ImplService service = new SI05ImplService();
                      service.Url = PubHelper.GetAddress(service.Url);

                      bool flag1 = false;

                      accountReturnDto dto;
                      dto = new accountReturnDto();

                      foreach (ARBillLine line in ARbillhead.ARBillLines)
                      {
                          if (line.SrcDocType == ARBillSrcDocTypeEnum.ShipmentBill && line.SrcBillLineID > 0)
                          {
                              #region ��������Ӧ��
                              ShipLine shipline = ShipLine.Finder.FindByID(line.SrcBillLineID);

                              if (shipline != null && (shipline.Ship.DocumentType.Code == "XM10" || shipline.Ship.DocumentType.Code == "XM1" || shipline.Ship.DocumentType.Code == "XM7" || shipline.Ship.DocumentType.Code == "XM4"))
                              {

                                  dto.dealerCode = ARbillhead.AccrueCust.Customer.Code;
                                  if (ARbillhead.AccrueCust.Customer.CustomerCategoryKey != null)
                                  {
                                      dto.customerType = ARbillhead.AccrueCust.Customer.CustomerCategory.Code;
                                  }
                                  
                                  dto.DMSShipNo = shipline.Ship.DescFlexField.PrivateDescSeg1;
                                  dto.dmsSaleNo = shipline.DescFlexField.PubDescSeg5;
                                  dto.earnestMoney = shipline.DescFlexField.PubDescSeg13;
                                  dto.vin = line.DescFlexField.PubDescSeg12;

                                  dto.deposit = shipline.DescFlexField.PubDescSeg21;
                                  dto.shipMoney = shipline.DescFlexField.PubDescSeg14;
                                 

                                  dto.amount += double.Parse((line.AROCMoney.NonTax + line.AROCMoney.GoodsTax).ToString());


                                  dto.operaTionType = "0";

                                  flag1 = true;
                              }
                              #endregion
                          }
                          else if (line.SrcDocType == ARBillSrcDocTypeEnum.RMA && line.SrcBillLineID > 0)
                          {
                              #region �˻ش���������Ӧ��
                              RMALine srcline = RMALine.Finder.FindByID(line.SrcBillLineID);
                              if (srcline != null)
                              {
                                 // dto = new accountReturnDto();

                                  dto.dealerCode = srcline.RMA.Customer.Customer.Code;

                                  dto.DMSShipNo = srcline.RMA.DescFlexField.PrivateDescSeg1;
                                  dto.dmsSaleNo = srcline.RMA.DescFlexField.PubDescSeg5;
                                  dto.earnestMoney = srcline.RMA.DescFlexField.PubDescSeg13;
                                  dto.deposit = srcline.RMA.DescFlexField.PubDescSeg21;
                                  dto.shipMoney = srcline.RMA.DescFlexField.PubDescSeg14;

                                  if (srcline.RMA.Customer.Customer.CustomerCategoryKey != null)
                                  {
                                      dto.customerType = srcline.RMA.Customer.Customer.CustomerCategory.Code;
                                  }
                                  dto.vin = srcline.RMA.DescFlexField.PubDescSeg12;
                                  dto.amount += double.Parse((line.AROCMoney.NonTax + line.AROCMoney.GoodsTax).ToString());
                                  dto.operaTionType = "1";
                                  flag1 = true;
                              }
                              #endregion
                          }
                      }

                      try
                      {
                          if (flag1)
                          {
                              accountReturnDto c = service.receive(dto);
                              if (c != null && c.flag == 0)
                                  throw new ApplicationException(c.errMsg);
                          }
                      }
                      catch (Exception e)
                      {

                          throw new ApplicationException("����DMS�ӿڴ���" + e.Message);
                      }
                  }
              }

            #endregion
        }
    }
    #endregion
}
