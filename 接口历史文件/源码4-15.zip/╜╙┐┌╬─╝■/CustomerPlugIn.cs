using System;
using System.Collections.Generic;
using System.Text;
using UFSoft.UBF.Business;
using UFIDA.U9.CBO.SCM.Customer;
using UFIDA.U9.Base.Location;
using UFIDA.U9.Base.Contact;
using UFIDA.U9.Cust.HBDY.DaYunPlugIn.DMS_SI08;

namespace UFIDA.U9.Cust.HBDY.DaYunPlugIn
{
    #region �ͻ�����
    public class CustomerInserted : UFSoft.UBF.Eventing.IEventSubscriber
    {
        public void Notify(params object[] args)
        {

            #region ���¼�������ȡ�õ�ǰҵ��ʵ��

            //���¼�������ȡ�õ�ǰҵ��ʵ��
            if (args == null || args.Length == 0 || !(args[0] is UFSoft.UBF.Business.EntityEvent))
                return;
            BusinessEntity.EntityKey key = ((UFSoft.UBF.Business.EntityEvent)args[0]).EntityKey;
            if (key == null)
                return;
            Customer customer = key.GetEntity() as Customer;
            //�ͻ�����ʱ����DMS�����ͻ�����
              bool flag = PubHelper.IsUsedDMSAPI();
              if (flag)
              {
                  if (customer.CustomerCategoryKey != null && (customer.CustomerCategory.Code == "101007" || customer.CustomerCategory.Code == "101006"))
                  {
                      try
                      {
                          SI08ImplService service = new SI08ImplService();
                          service.Url = PubHelper.GetAddress(service.Url);

                          List<dealerInfoDto> list = new List<dealerInfoDto>();
                          dealerInfoDto dto = new dealerInfoDto();


                          dto.dealerCode = customer.Code;
                          dto.dealerName = customer.Name;
                          dto.dealerShortName = customer.ShortName;

                          dto.companyCode = customer.Code;
                          dto.companyName = customer.Name;
                          dto.companyShortName = customer.ShortName;

                          //if (customer.OfficialLocationKey != null)
                          //{
                          // Location location = customer.OfficialLocation;

                          //string province = location.ProvinceKey == null ? "" : location.Province.Code;
                          //string City = location.CityKey == null ? "" : location.City.Code;
                          //string Area = location.CountryKey == null ? "" : location.Country.Code;
                          //string postalCode = location.PostalCodeKey == null ? "" : location.PostalCode.PostalCode;


                          //}

                          //if (customer.DefaultContactKey != null)
                          //{
                          //    Contact link = customer.DefaultContact;
                          //    string LinkMna = link.Code;
                          //    string legalMan = link.Code;
                          //    string LinkPhone = link.DefaultMobilNum;
                          //    string leganPhone = link.DefaultMobilNum;
                          //    string Fax = link.DefaultFaxNum;
                          //    string Email = link.DefaultEmail;
                          //    string Address = link.DefaultLocation.Address1;
                          //}

                          //string CorpUnifyCode = customer.CorpUnifyCode;
                          //string TaxNo = string.Format("{0}/{1}", customer.StateTaxNo, customer.DistrictTaxNo);
                          //bool recognizance = customer.IsDeposit;

                          if (customer.CustomerCategoryKey != null)
                          {
                              dto.dealerType = int.Parse(customer.CustomerCategory.Code);
                          }
                          dto.actionType = 1;
                          list.Add(dto);

                          dealerInfoDto d = service.receive(list.ToArray());
                          if (d != null && d.flag == 0)
                              throw new ApplicationException(d.errMsg);
                      }
                      catch (Exception e)
                      {

                          throw new ApplicationException("����DMS�ӿڴ���" + e.Message);
                      }

                  }
              }
            #endregion
        }
    }
    #endregion
    #region �ͻ�ɾ��
    public class CustomerDeleted : UFSoft.UBF.Eventing.IEventSubscriber
    {
        public void Notify(params object[] args)
        {

            #region ���¼�������ȡ�õ�ǰҵ��ʵ��

            //���¼�������ȡ�õ�ǰҵ��ʵ��
            if (args == null || args.Length == 0 || !(args[0] is UFSoft.UBF.Business.EntityEvent))
                return;
            BusinessEntity.EntityKey key = ((UFSoft.UBF.Business.EntityEvent)args[0]).EntityKey;
            if (key == null)
                return;
            Customer customer = key.GetEntity() as Customer;
              bool flag = PubHelper.IsUsedDMSAPI();
              if (flag)
              {
                  //�ͻ�ɾ��ʱ����DMSɾ���ͻ�����
                  if (customer.CustomerCategoryKey != null && (customer.CustomerCategory.Code == "101007" || customer.CustomerCategory.Code == "101006"))
                  {
                      try
                      {
                          SI08ImplService service = new SI08ImplService();
                          service.Url = PubHelper.GetAddress(service.Url);

                          List<dealerInfoDto> list = new List<dealerInfoDto>();
                          dealerInfoDto dto = new dealerInfoDto();


                          dto.dealerCode = customer.Code;
                          dto.dealerName = customer.Name;
                          dto.dealerShortName = customer.ShortName;

                          dto.companyCode = customer.Code;
                          dto.companyName = customer.Name;
                          dto.companyShortName = customer.ShortName;

                          //if (customer.OfficialLocationKey != null)
                          //{
                          // Location location = customer.OfficialLocation;

                          //string province = location.ProvinceKey == null ? "" : location.Province.Code;
                          //string City = location.CityKey == null ? "" : location.City.Code;
                          //string Area = location.CountryKey == null ? "" : location.Country.Code;
                          //string postalCode = location.PostalCodeKey == null ? "" : location.PostalCode.PostalCode;


                          //}

                          //if (customer.DefaultContactKey != null)
                          //{
                          //    Contact link = customer.DefaultContact;
                          //    string LinkMna = link.Code;
                          //    string legalMan = link.Code;
                          //    string LinkPhone = link.DefaultMobilNum;
                          //    string leganPhone = link.DefaultMobilNum;
                          //    string Fax = link.DefaultFaxNum;
                          //    string Email = link.DefaultEmail;
                          //    string Address = link.DefaultLocation.Address1;
                          //}

                          //string CorpUnifyCode = customer.CorpUnifyCode;
                          //string TaxNo = string.Format("{0}/{1}", customer.StateTaxNo, customer.DistrictTaxNo);
                          //bool recognizance = customer.IsDeposit;

                          if (customer.CustomerCategoryKey != null)
                          {
                              dto.dealerType = int.Parse(customer.CustomerCategory.Code);
                          }
                          dto.actionType = 3;
                          list.Add(dto);

                          dealerInfoDto d = service.receive(list.ToArray());
                          if (d != null && d.flag == 0)
                              throw new ApplicationException(d.errMsg);
                      }
                      catch (Exception e)
                      {

                          throw new ApplicationException("����DMS�ӿڴ���" + e.Message);
                      }

                  }

              }
            #endregion
        }
    }
    #endregion
    #region �ͻ��޸�
    public class CustomerUpdated : UFSoft.UBF.Eventing.IEventSubscriber
    {
        public void Notify(params object[] args)
        {

            #region ���¼�������ȡ�õ�ǰҵ��ʵ��

            //���¼�������ȡ�õ�ǰҵ��ʵ��
            if (args == null || args.Length == 0 || !(args[0] is UFSoft.UBF.Business.EntityEvent))
                return;
            BusinessEntity.EntityKey key = ((UFSoft.UBF.Business.EntityEvent)args[0]).EntityKey;
            if (key == null)
                return;
            Customer customer = key.GetEntity() as Customer;
              bool flag = PubHelper.IsUsedDMSAPI();
              if (flag)
              {
                  //�ͻ��޸�ʱ����DMS�޸Ŀͻ�����
                  if (customer.CustomerCategoryKey != null && (customer.CustomerCategory.Code == "101007" || customer.CustomerCategory.Code == "101006"))
                  {
                      try
                      {
                          SI08ImplService service = new SI08ImplService();
                          service.Url = PubHelper.GetAddress(service.Url);

                          List<dealerInfoDto> list = new List<dealerInfoDto>();
                          dealerInfoDto dto = new dealerInfoDto();


                          dto.dealerCode = customer.Code;
                          dto.dealerName = customer.Name;
                          dto.dealerShortName = customer.ShortName;

                          dto.companyCode = customer.Code;
                          dto.companyName = customer.Name;
                          dto.companyShortName = customer.ShortName;

                          //if (customer.OfficialLocationKey != null)
                          //{
                          // Location location = customer.OfficialLocation;

                          //string province = location.ProvinceKey == null ? "" : location.Province.Code;
                          //string City = location.CityKey == null ? "" : location.City.Code;
                          //string Area = location.CountryKey == null ? "" : location.Country.Code;
                          //string postalCode = location.PostalCodeKey == null ? "" : location.PostalCode.PostalCode;


                          //}

                          //if (customer.DefaultContactKey != null)
                          //{
                          //    Contact link = customer.DefaultContact;
                          //    string LinkMna = link.Code;
                          //    string legalMan = link.Code;
                          //    string LinkPhone = link.DefaultMobilNum;
                          //    string leganPhone = link.DefaultMobilNum;
                          //    string Fax = link.DefaultFaxNum;
                          //    string Email = link.DefaultEmail;
                          //    string Address = link.DefaultLocation.Address1;
                          //}

                          //string CorpUnifyCode = customer.CorpUnifyCode;
                          //string TaxNo = string.Format("{0}/{1}", customer.StateTaxNo, customer.DistrictTaxNo);
                          //bool recognizance = customer.IsDeposit;

                          if (customer.CustomerCategoryKey != null)
                          {
                              dto.dealerType = int.Parse(customer.CustomerCategory.Code);
                          }
                          dto.actionType = 2;
                          list.Add(dto);

                          dealerInfoDto d = service.receive(list.ToArray());
                          if (d != null && d.flag == 0)
                              throw new ApplicationException(d.errMsg);
                      }
                      catch (Exception e)
                      {

                          throw new ApplicationException("����DMS�ӿڴ���" + e.Message);
                      }
                  }

              }
            #endregion
        }
    }
    #endregion
}
