﻿namespace UFIDA.U9.Cust.HBDY.API.SalesOrderSV
{
	using System;
	using System.Collections.Generic;
	using System.Text; 
	using UFSoft.UBF.AopFrame;	
	using UFSoft.UBF.Util.Context;
    using UFIDA.U9.CBO.SCM.Customer;
    using UFIDA.U9.CBO.SCM.Item;
    using UFIDA.U9.Base;
    using UFIDA.U9.SM.SO;
    using UFIDA.U9.CBO.Pub.Controller;
    using UFIDA.U9.CBO.SCM.ProjectTask;
    using UFSoft.UBF.Business;
    using UFSoft.UBF.PL.Engine;

	/// <summary>
	/// CreateApprovedSaleOrderSV partial 
	/// </summary>	
	public partial class CreateApprovedSaleOrderSV 
	{	
		internal BaseStrategy Select()
		{
			return new CreateApprovedSaleOrderSVImpementStrategy();	
		}		
	}
	
	#region  implement strategy	
	/// <summary>
	/// Impement Implement
	/// 
	/// </summary>	
	internal partial class CreateApprovedSaleOrderSVImpementStrategy : BaseStrategy
	{
		public CreateApprovedSaleOrderSVImpementStrategy() { }

		public override object Do(object obj)
		{						
			CreateApprovedSaleOrderSV bpObj = (CreateApprovedSaleOrderSV)obj;

            List<SoBackDTO> results = new List<SoBackDTO>();
            SoBackDTO result = new SoBackDTO();

            #region 参数校验
            if (bpObj.SoLineDto == null || bpObj.SoLineDto.Count==0)
            {
                result.IsSuccess = false;
                result.ErrorInfo = "传入参数不可为空";
                result.Timestamp = DateTime.Now.ToString();
                results.Add(result);
                return results;
            }
            //参数合法校验
            string usercode = bpObj.SoLineDto[0].UserCode;
            string enterprise = bpObj.SoLineDto[0].EnterpriseCode;

            string errormessage = ValidateParamNullOrEmpty(bpObj);

           if (!string.IsNullOrEmpty(errormessage))
           {
               result.IsSuccess = false;
               result.ErrorInfo = errormessage;
               result.Timestamp = DateTime.Now.ToString();
              
               results.Add(result);
               return results;
           }
         
            #endregion

           List<UFIDA.U9.SM.SO.SOStatusDTOData> statusDTOs = null;

           using (UFSoft.UBF.Transactions.UBFTransactionScope trans1 = new UFSoft.UBF.Transactions.UBFTransactionScope(UFSoft.UBF.Transactions.TransactionOption.RequiresNew))
           {
               #region 创建项目
               using (ISession session = Session.Open())
               {
                   foreach (SoLineDTO line in bpObj.SoLineDto)
                   {
                       if (string.IsNullOrEmpty(line.DmsSaleNo))
                           continue;
                       Project project = Project.Finder.Find(string.Format("Org={0} and Code='{1}'", Context.LoginOrg.ID.ToString(), line.DmsSaleNo));
                       if (project == null)
                       {
                           Project p = Project.Create();
                           p.Org = Context.LoginOrg;
                           p.StartDate = DateTime.Now;
                           p.EndDate = DateTime.Now;
                           p.Code = line.DmsSaleNo;
                           p.Name = line.DmsSaleNo;
                           p.Effective = new UFIDA.U9.Base.PropertyTypes.Effective();
                           p.Effective.IsEffective = true;
                           p.Effective.EffectiveDate = Convert.ToDateTime("2000.01.01 00:00:00");
                           p.Effective.DisableDate = Convert.ToDateTime("9999.12.31");
                       }
                   }
                   session.Commit();
               }
               #endregion
               #region 创建销售订单
               List<CommonArchiveDataDTOData> resultsolist;
               try
               {
                   UFIDA.U9.ISV.SM.Proxy.CommonCreateSOSRVProxy proxy = new UFIDA.U9.ISV.SM.Proxy.CommonCreateSOSRVProxy();
                   proxy.SOs = GetSaleOrderDTODataList(bpObj);

                   proxy.ContextDTO = new ContextDTOData();
                   proxy.ContextDTO.OrgID = Context.LoginOrg.ID;
                   proxy.ContextDTO.OrgCode = Context.LoginOrg.Code;
                   proxy.ContextDTO.EntCode=enterprise;
                   //proxy.ContextDTO.UserID = long.Parse(Context.LoginUserID);
                   proxy.ContextDTO.UserCode = usercode;
                   proxy.ContextDTO.CultureName = Context.LoginLanguageCode;

                   resultsolist = proxy.Do();


                   //}
                   //catch (Exception e)
                   //{
                   //    result.IsSuccess = false;
                   //    result.ErrorInfo = e.Message;
                   //    result.Timestamp = DateTime.Now.ToString();

                   //    result.ERPDocNo = string.Empty;
                   //    results.Add(result);
                   //    return results;
                   //}
                   if (resultsolist == null || resultsolist.Count == 0)
                   {
                       result.IsSuccess = false;
                       result.ErrorInfo = "没有生成销售订单";
                       result.Timestamp = DateTime.Now.ToString();

                       results.Add(result);
                       return results;
                   }


               #endregion         
               #region 提交审核销售订单
                   //long createsoid = resultsolist[0].ID;
                   //try
                   //{
                   UFIDA.U9.SM.SO.Proxy.SOStatusTransferBPProxy bp = new SM.SO.Proxy.SOStatusTransferBPProxy();

                   bp.SOKeyDTOList = new List<SM.SO.SOKeyDTOData>();
                   foreach (CommonArchiveDataDTOData d in resultsolist)
                   {
                       UFIDA.U9.SM.SO.SOKeyDTOData dto = new SM.SO.SOKeyDTOData();
                       // List<UFIDA.U9.SM.SO.SOStatusDTOData> statusDTOs = null;
                       dto.SOkey = d.ID;
                       //dto.SOSysVersion = long.Parse(_part.Model.Views[0].FocusedRecord["SysVersion"].ToString());
                       dto.TargetStatus = 2;//审核中

                       bp.SOKeyDTOList.Add(dto);
                   }
                   statusDTOs = bp.Do();

                   bp = new SM.SO.Proxy.SOStatusTransferBPProxy();
                   bp.SOKeyDTOList = new List<SM.SO.SOKeyDTOData>();
                   foreach (SOStatusDTOData dt in statusDTOs)
                   {
                       UFIDA.U9.SM.SO.SOKeyDTOData dto = new SM.SO.SOKeyDTOData();
                       dto.SOkey = dt.SOID;
                       dto.SOSysVersion = dt.SysVersion;
                       dto.TargetStatus = 3;//已审核

                       bp.SOKeyDTOList.Add(dto);
                   }
                   statusDTOs = bp.Do();

                   trans1.Commit();

                  
               }
               catch (Exception e)
               {
                   trans1.Rollback();

                   result.IsSuccess = false;
                   result.ErrorInfo = e.Message;
                   result.Timestamp = DateTime.Now.ToString();

                   results.Add(result);

                   return result;
               }
             #endregion
           }
           if (statusDTOs != null && statusDTOs.Count > 0)
           {
               foreach (SOStatusDTOData dt in statusDTOs)
               {
                   SO so = SO.Finder.FindByID(dt.SOID);
                   if (so != null)
                   {
                       result.IsSuccess = true;
                       result.ErrorInfo = "生单成功";
                       result.DMSDocNo = so.DescFlexField.PubDescSeg5;
                       result.ERPDocNo = so.DocNo;
                       results.Add(result);
                   }

               }
           }
            return results;
           
		}

        /// <summary>
        /// 传入参数非空校验
        /// </summary>
        /// <param name="bpObj"></param>
        private string ValidateParamNullOrEmpty(CreateApprovedSaleOrderSV bpObj)
        {

            #region 传入参数校验

            
            string errormessage = string.Empty;
           

            foreach (SoLineDTO solinedto in bpObj.SoLineDto)
            {
                
                //经销商代码
                if (string.IsNullOrEmpty(solinedto.DealerCode))
                    errormessage += string.Format("[{0}]DMS销售订单的[经销商代码]不可为空,", solinedto.DmsSaleNo);
                else
                {
                    Customer customer = Customer.Finder.Find(string.Format("Org={0} and Code='{1}'", Context.LoginOrg.ID.ToString(), solinedto.DealerCode));
                    if (customer == null)
                        errormessage += string.Format("[{0}]DMS销售订单的[经销商代码({1})]在U9系统中找不到对应的客户档案,请同步,", solinedto.DmsSaleNo,solinedto.DealerCode);
                }

                //订单类型
                if (string.IsNullOrEmpty(solinedto.OrderType))
                    errormessage += string.Format("[{0}]DMS销售订单的[订单类型]不可为空,", solinedto.DmsSaleNo);
                else
                {
                    SODocType doctype = SODocType.Finder.Find(string.Format("Org={0} and Code='{1}'", Context.LoginOrg.ID.ToString(), solinedto.OrderType));
                    if (doctype == null)
                        errormessage += string.Format("[{0}]DMS销售订单的[订单类型]在U9系统中找不到对应的[销售单据类型({1})],请同步,", solinedto.DmsSaleNo,solinedto.OrderType);
                }

                //物料编号
                if (string.IsNullOrEmpty(solinedto.ErpMaterialCode))
                    errormessage += string.Format("[{0}]DMS销售订单的参数SOLines的[ERP物料编号]不可为空,", solinedto.DmsSaleNo);
                else
                {
                    ItemMaster item = ItemMaster.Finder.Find(string.Format("Org={0} and Code='{1}'", Context.LoginOrg.ID.ToString(), solinedto.ErpMaterialCode));
                    if (item == null)
                        errormessage += string.Format("[{0}]DMS销售订单的参数SOLines的[ERP物料编号({1})]在U9系统中找不到对应的料品档案,请同步,", solinedto.DmsSaleNo,solinedto.ErpMaterialCode);
                }

            }

            return errormessage;
            #endregion


        }
        /// <summary>
        /// 得到销售订单dto
        /// </summary>
        /// <param name="bpObj"></param>
        /// <returns></returns>
        private List<UFIDA.U9.ISV.SM.SaleOrderDTOData> GetSaleOrderDTODataList(CreateApprovedSaleOrderSV bpObj)
        {
            List<UFIDA.U9.ISV.SM.SaleOrderDTOData> list = new List<UFIDA.U9.ISV.SM.SaleOrderDTOData>();

            UFIDA.U9.ISV.SM.SaleOrderDTOData sodto;
          
            Dictionary<string,List<SoLineDTO>> dic=new Dictionary<string,List<SoLineDTO>>();

                
                foreach (SoLineDTO solinedto in bpObj.SoLineDto)
                {
                    if (!dic.ContainsKey(solinedto.SpitOrderFlag))
                        dic.Add(solinedto.SpitOrderFlag, new List<SoLineDTO>());

                    dic[solinedto.SpitOrderFlag].Add(solinedto);
                }

                foreach (string key in dic.Keys)
                {
                    sodto = new UFIDA.U9.ISV.SM.SaleOrderDTOData();
                    #region 销售订单头处理
                    //单据类型
                    //SODocType doctype = SODocType.Finder.Find(string.Format("Org={0} and Code='{0}'", Context.LoginOrg.ID.ToString(), srcsodto.OrderType.ToString()));
                    sodto.DocumentType = new UFIDA.U9.CBO.Pub.Controller.CommonArchiveDataDTOData();
                    //sodto.DocumentType.ID = doctype.ID;
                    sodto.DocumentType.Code = dic[key][0].OrderType;
                    //sodto.DocumentType.Name = doctype.Name;
                   
                    //客户
                    //Customer customer = Customer.Finder.Find(string.Format("Org={0} and Code='{0}'", Context.LoginOrg.ID.ToString(), srcsodto.DealerCode));
                    sodto.OrderBy = new CustomerMISCInfoData();
                    //sodto.OrderBy.Customer = customer.ID;
                    sodto.OrderBy.Code = dic[key][0].DealerCode;
                    //sodto.OrderBy.Name = customer.Name;
                    sodto.SOSrcType = SOSourceTypeEnum.Manual.Value;
                    //币种
                    sodto.TC = new UFIDA.U9.CBO.Pub.Controller.CommonArchiveDataDTOData();
                    sodto.TC.Code = string.IsNullOrEmpty(dic[key][0].Currency) ? "C001" : dic[key][0].Currency;

                    
                    //DMS销售订单编号
                    sodto.DescFlexField = new UFIDA.U9.Base.FlexField.DescFlexField.DescFlexSegmentsData();
                    sodto.DescFlexField.PubDescSeg5 = dic[key][0].DmsSaleNo;
                     
                  

               
                    //出货原则不可空(默认来源客户)

                    // 2： 业务类型普通销售,成交方式不可为空否则无法提交。默认来源客户
                    string RecTerm = "01";
                    Customer customer = Customer.Finder.Find(string.Format("Org={0} and Code='{1}'", Context.LoginOrg.ID.ToString(), dic[key][0].DealerCode));
                    if (customer != null)
                    {
                        sodto.ConfirmTerm = new CommonArchiveDataDTOData();
                        if (customer.ARConfirmTerm != null)
                            sodto.ConfirmTerm.Code = customer.ARConfirmTerm.Code;
                        else
                            sodto.ConfirmTerm.Code = "01";

                        sodto.BargainMode = customer.Bargain.Value;
                        sodto.ShipRule = new CommonArchiveDataDTOData();
                        if (customer.ShippmentRuleKey != null)
                        {

                            sodto.ShipRule.Code = customer.ShippmentRule.Code;
                        }
                        else
                            sodto.ShipRule.Code = "C001";

                        if (customer.RecervalTermKey != null)
                            RecTerm = customer.RecervalTerm.Code;

                    }
                    else
                    {
                        sodto.ShipRule.Code = "C001";
                        sodto.BargainMode = 0;

                        sodto.ConfirmTerm = new CommonArchiveDataDTOData();
                        sodto.ConfirmTerm.Code = "01";
                    }

                    #endregion
                    #region 销售订单行处理
                    sodto.SOLines = new List<UFIDA.U9.ISV.SM.SOLineDTOData>();

                    UFIDA.U9.ISV.SM.SOLineDTOData solinedto;
                    UFIDA.U9.ISV.SM.SOShipLineDTOData soshipliendto;
                    foreach (SoLineDTO srcsolinedto in dic[key])
                    {
                        solinedto = new UFIDA.U9.ISV.SM.SOLineDTOData();

                        //料品
                        solinedto.ItemInfo = new ItemInfoData();
                        solinedto.ItemInfo.ItemCode = srcsolinedto.ErpMaterialCode;

                        if (!string.IsNullOrEmpty(srcsolinedto.FinalPrice))
                            solinedto.FinallyPriceTC = decimal.Parse(srcsolinedto.FinalPrice);
                        
                        if (!string.IsNullOrEmpty(srcsolinedto.Number))
                            solinedto.OrderByQtyPU = decimal.Parse(srcsolinedto.Number);
                        else
                            solinedto.OrderByQtyPU = 1; 

                        if (!string.IsNullOrEmpty(srcsolinedto.Money))
                            solinedto.TotalMoneyTC = decimal.Parse(srcsolinedto.Money);

                        solinedto.Project = new CommonArchiveDataDTOData();
                        solinedto.Project.Code = srcsolinedto.DmsSaleNo;

                        solinedto.SrcDocType = SOSourceTypeEnum.Manual.Value;

                        solinedto.RecTerm = new CommonArchiveDataDTOData();
                        solinedto.RecTerm.Code = RecTerm;

                     

                        solinedto.DescFlexField = new UFIDA.U9.Base.FlexField.DescFlexField.DescFlexSegmentsData();
                        solinedto.DescFlexField.PrivateDescSeg1 = srcsolinedto.MaterialCode;
                      

                        solinedto.SOShiplines = new List<UFIDA.U9.ISV.SM.SOShipLineDTOData>();
                        soshipliendto = new UFIDA.U9.ISV.SM.SOShipLineDTOData();

                        soshipliendto.Project = new CommonArchiveDataDTOData();
                        soshipliendto.Project.Code = srcsolinedto.DmsSaleNo;

                        soshipliendto.ItemInfo = new ItemInfoData();
                        soshipliendto.ItemInfo.ItemCode = srcsolinedto.ErpMaterialCode;
                        soshipliendto.IsMRPRequire = true;
                        soshipliendto.RequireDate = string.IsNullOrEmpty(srcsolinedto.DeliveryDate) ? DateTime.Now : Convert.ToDateTime(srcsolinedto.DeliveryDate);
                        solinedto.SOShiplines.Add(soshipliendto);

                        sodto.SOLines.Add(solinedto);

                    }
                    #endregion

                    list.Add(sodto);
                }
            return list;
        }
	}

	#endregion
	
	
}