using System;
using System.Collections.Generic;
using System.Text;
using UFSoft.UBF.Business;
using UFIDA.U9.SM.SO;
using UFIDA.U9.Cust.HBDY.DaYunPlugIn.DMS_SI02;
using UFIDA.U9.Cust.HBDY.API.RMASV.Proxy;
using UFIDA.U9.Cust.HBDY.API.RMASV;
using System.Xml;
using System.Web;
using UFIDA.U9.Cust.HBDY.API.TransferInSV.Proxy;
using UFIDA.U9.Cust.HBDY.API.TransferInSV;
using UFIDA.U9.Cust.HBDY.DipatchOutWhAPISV.Proxy;
using UFIDA.U9.Cust.HBDY.API.SalesOrderSV.Proxy;
using UFIDA.U9.Cust.HBDY.API.SalesOrderSV;
using UFIDA.U9.Cust.HBDY.API.ShipSV.Proxy;

namespace UFIDA.U9.Cust.HBDY.DaYunPlugIn
{
    #region ���۶���Deleted
    public class SODeleted : UFSoft.UBF.Eventing.IEventSubscriber
    {
        public void Notify(params object[] args)
        {

            #region ���¼�������ȡ�õ�ǰҵ��ʵ��

            //���¼�������ȡ�õ�ǰҵ��ʵ��
            if (args == null || args.Length == 0 || !(args[0] is UFSoft.UBF.Business.EntityEvent))
                return;
            BusinessEntity.EntityKey key = ((UFSoft.UBF.Business.EntityEvent)args[0]).EntityKey;
            if (key == null)
                return;
            SO so = key.GetEntity() as SO;
            //���۶���ɾ��ʱ������DMS�ӿ�

            //CreateShipSVProxy proxy = new CreateShipSVProxy();
            //proxy.ShipLineDTOs = new List<UFIDA.U9.Cust.HBDY.API.ShipSV.ShipLineDTOData>();


            //UFIDA.U9.Cust.HBDY.API.ShipSV.ShipLineDTOData dto = new UFIDA.U9.Cust.HBDY.API.ShipSV.ShipLineDTOData();
            //= "HM-P111-Q1047";
            //dto.DmsSaleNo = "2QY1602015046Z002";
            //dto.ErpMaterialCode = "3836N-010";
            //dto.Number = 1;
            //dto.WHOut = "SHBJ";
            //dto.Lot = "1502031151";
            //dto.MaterialCode = "110160";
            //dto.SpitOrderFlag = "1";
            //dto.OrderType = "3";

            //dto.DmsSaleNo = "FDY0998173150415001";
            //dto.ErpMaterialCode = "2402N-355";
            //dto.Number = 2;
            //dto.WHOut = "SHBJ";
            //dto.Lot = "1403020111";
            //dto.MaterialCode = "110150";
            //dto.SpitOrderFlag = "1";
            //dto.OrderType = "3";

            //proxy.ShipLineDTOs.Add(dto);

            //UFIDA.U9.Cust.HBDY.API.ShipSV.ShipLineDTOData dto1 = new UFIDA.U9.Cust.HBDY.API.ShipSV.ShipLineDTOData();
            //dto1.DmsSaleNo = "FDY0998173150415001";
            //dto1.ErpMaterialCode = "84C-00011";
            //dto1.Number = 2;
            //dto1.WHOut = "SHBJ";
            //dto1.Lot = "1409120173";
            //dto1.MaterialCode = "110136";
            //dto1.SpitOrderFlag = "1";
            //dto1.OrderType = "3";


            //proxy.ShipLineDTOs.Add(dto1);
            //proxy.Do();

         // string s=HttpRuntime.AppDomainAppPath.ToString();
           // string t=Request.ApplicationPath


            bool flag = PubHelper.IsUsedDMSAPI();
            if (flag)
            {
                if (!string.IsNullOrEmpty(so.DescFlexField.PubDescSeg5))
                {
                    try
                    {
                        List<orderInfoDto> list = new List<orderInfoDto>();
                        SI02ImplService service = new SI02ImplService();
                        service.Url = PubHelper.GetAddress(service.Url);

                        orderInfoDto dto = new orderInfoDto();
                        dto.docStatus = "2";
                        dto.dmsSaleNo = so.DescFlexField.PubDescSeg5;
                        list.Add(dto);
                        service.receive(list.ToArray());
                    }
                    catch (Exception e)
                    {
                        throw new ApplicationException("����DMS�ӿڴ���" + e.Message);
                    }
                }

            }
            #endregion
        }
    }
    #endregion
    #region ���۶���Updated
    //public class SOUpdated : UFSoft.UBF.Eventing.IEventSubscriber
    //{
    //    public void Notify(params object[] args)
    //    {

    //        #region ���¼�������ȡ�õ�ǰҵ��ʵ��

    //        //���¼�������ȡ�õ�ǰҵ��ʵ��
    //        if (args == null || args.Length == 0 || !(args[0] is UFSoft.UBF.Business.EntityEvent))
    //            return;
    //        BusinessEntity.EntityKey key = ((UFSoft.UBF.Business.EntityEvent)args[0]).EntityKey;
    //        if (key == null)
    //            return;
    //        SO so = key.GetEntity() as SO;
    //        //״̬����˵���ȱ�ر�ʱ����DMS�ӿ�
    //        if (so.OriginalData.Status == SODocStatusEnum.Approved && so.Status == SODocStatusEnum.CloseShort)
    //        {
    //            try
    //            {
    //                List<orderInfoDto> list = new List<orderInfoDto>();
    //                SI02ImplService service = new SI02ImplService();
    //                orderInfoDto dto = new orderInfoDto();
    //                dto.docStatus = 1;
    //                dto.dmsSaleNo = so.DescFlexField.PubDescSeg5;
    //                list.Add(dto);
    //                service.receive(list.ToArray());
    //            }
    //            catch (Exception e)
    //            {
    //                throw new ApplicationException("����DMS�ӿڴ���" + e.Message);
    //            }
    //        }



    //        #endregion
    //    }
    //}
    #endregion
    #region ���۶���Inserted
    //public class SOInserted : UFSoft.UBF.Eventing.IEventSubscriber
    //{
    //    public void Notify(params object[] args)
    //    {

    //        #region ���¼�������ȡ�õ�ǰҵ��ʵ��

    //        //���¼�������ȡ�õ�ǰҵ��ʵ��
    //        if (args == null || args.Length == 0 || !(args[0] is UFSoft.UBF.Business.EntityEvent))
    //            return;
    //        BusinessEntity.EntityKey key = ((UFSoft.UBF.Business.EntityEvent)args[0]).EntityKey;
    //        if (key == null)
    //            return;
    //        SO so = key.GetEntity() as SO;
           
    //            try
    //            {
    //                List<orderInfoDto> list = new List<orderInfoDto>();
    //                SI02ImplService service = new SI02ImplService();
    //                orderInfoDto dto = new orderInfoDto();
    //                dto.docStatus = 0;
    //                dto.dmsSaleNo = so.DescFlexField.PubDescSeg5;
    //                list.Add(dto);
    //                service.receive(list.ToArray());
    //            }
    //            catch (Exception e)
    //            {
    //                throw new ApplicationException("����DMS�ӿڴ���" + e.Message);
    //            }
           



    //        #endregion
    //    }
    //}
     #endregion
 
}
