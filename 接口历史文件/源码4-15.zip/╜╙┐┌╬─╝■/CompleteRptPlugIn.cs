using System;
using System.Collections.Generic;
using System.Text;
using UFSoft.UBF.Business;
using UFIDA.U9.MO.Complete;
using UFIDA.U9.Cust.HBDY.DaYunPlugIn.DMS_SI09;
using UFIDA.U9.Cust.HBDY.DaYunPlugIn.DMS_SI03;

namespace UFIDA.U9.Cust.HBDY.DaYunPlugIn
{
    #region �깤����Updated
    public class CompleteRptUpdated : UFSoft.UBF.Eventing.IEventSubscriber
    {
        public void Notify(params object[] args)
        {

            #region ���¼�������ȡ�õ�ǰҵ��ʵ��

            //���¼�������ȡ�õ�ǰҵ��ʵ��
            if (args == null || args.Length == 0 || !(args[0] is UFSoft.UBF.Business.EntityEvent))
                return;
            BusinessEntity.EntityKey key = ((UFSoft.UBF.Business.EntityEvent)args[0]).EntityKey;
            if (key == null)
                return;
            CompleteRpt rpt = key.GetEntity() as CompleteRpt;
              bool flag = PubHelper.IsUsedDMSAPI();
              if (flag)
              {

                  #region ����dms�ӿ�
                  if ((rpt.MOKey != null && rpt.MO.MODocType.Code != "MO02") || rpt.PLSKey!=null)
                  {
                      if (rpt.DescFlexField.PrivateDescSeg21 != rpt.OriginalData.DescFlexField.PrivateDescSeg21)   //��vin���дʱ
                      {
                          try
                          {
                              SI03ImplService service = new SI03ImplService();
                              service.Url = PubHelper.GetAddress(service.Url);

                              vehicleInfoDto dto = new vehicleInfoDto();

                              if (rpt.ProjectKey != null)
                                  dto.dmsSaleNo = rpt.Project.Code;
                              dto.vin = rpt.DescFlexField.PubDescSeg12;
                              dto.erpMaterialCode = rpt.Item.Code;
                              dto.nodeStatus = "4";
                              dto.oldVin = rpt.DescFlexField.PrivateDescSeg21;
                              dto.flowingCode = rpt.DescFlexField.PrivateDescSeg21.Length >= 8 ? rpt.DescFlexField.PrivateDescSeg21.Substring(rpt.DescFlexField.PrivateDescSeg21.Length - 8, 8) : rpt.DescFlexField.PrivateDescSeg21;

                              vehicleInfoDto resultdto = service.receive(dto);
                              if (resultdto != null && resultdto.flag == 0)
                                  throw new ApplicationException(resultdto.errMsg);
                          }
                          catch (Exception e)
                          {

                              throw new ApplicationException("����DMS�ӿڴ���" + e.Message);
                          }

                      }
                      else
                      {
                          if (rpt.DocState == UFIDA.U9.MO.Enums.CompleteRptStateEnum.Approved && rpt.OriginalData.DocState == UFIDA.U9.MO.Enums.CompleteRptStateEnum.Approving)
                          {
                              try
                              {
                                  SI03ImplService service = new SI03ImplService();
                                  service.Url = PubHelper.GetAddress(service.Url);

                                  vehicleInfoDto dto = new vehicleInfoDto();

                                  if (rpt.ProjectKey != null)
                                      dto.dmsSaleNo = rpt.Project.Code;
                                  dto.vin = rpt.DescFlexField.PubDescSeg12;
                                  dto.erpMaterialCode = rpt.Item.Code;
                                  dto.nodeStatus = "4";
                                  dto.oldVin = string.Empty;
                                  dto.flowingCode = rpt.DescFlexField.PubDescSeg12.Length >= 8 ? rpt.DescFlexField.PubDescSeg12.Substring(rpt.DescFlexField.PubDescSeg12.Length - 8, 8) : rpt.DescFlexField.PubDescSeg12;

                                  vehicleInfoDto resultdto = service.receive(dto);
                                  if (resultdto != null && resultdto.flag == 0)
                                      throw new ApplicationException(resultdto.errMsg);
                              }
                              catch (Exception e)
                              {

                                  throw new ApplicationException("����DMS�ӿڴ���" + e.Message);
                              }

                          }
                      }
                  }

                  //.���ƶ����깤���
                  if (rpt.OriginalData.ActualRcvTime != rpt.ActualRcvTime && rpt.ActualRcvTime != DateTime.MinValue && rpt.ActualRcvTime != null && rpt.MOKey != null && rpt.MO.MODocType.Code == "MO02")
                  {

                      try
                      {
                          SI09ImplService service = new SI09ImplService();
                          service.Url = PubHelper.GetAddress(service.Url);

                          vehicleChangeInfoDto dto = new vehicleChangeInfoDto();
                          dto.vin = rpt.DescFlexField.PubDescSeg12;
                          //string MODocNo = "";
                          dto.docStatus = 7;

                          vehicleChangeInfoDto d = service.receive(dto);
                          if (d != null && d.flag == 0)
                              throw new ApplicationException(d.errMsg);
                      }
                      catch (Exception e)
                      {

                          throw new ApplicationException("����DMS�ӿڴ���" + e.Message);
                      }


                  }
                  #endregion
              }
            #endregion
        }
    }
    #endregion

}