using System;
using System.Collections.Generic;
using System.Text;
using UFSoft.UBF.Business;
using UFIDA.U9.CBO.SCM.Supplier;
using UFIDA.U9.Cust.HBDY.DaYunPlugIn.DMS_PI08;

namespace UFIDA.U9.Cust.HBDY.DaYunPlugIn
{
    #region ��Ӧ������
    public class SupplierInserted : UFSoft.UBF.Eventing.IEventSubscriber
    {
        public void Notify(params object[] args)
        {

            #region ���¼�������ȡ�õ�ǰҵ��ʵ��

            //���¼�������ȡ�õ�ǰҵ��ʵ��
            if (args == null || args.Length == 0 || !(args[0] is UFSoft.UBF.Business.EntityEvent))
                return;
            BusinessEntity.EntityKey key = ((UFSoft.UBF.Business.EntityEvent)args[0]).EntityKey;
            if (key == null)
                return;
            Supplier supplier = key.GetEntity() as Supplier;
            //��Ӧ������ʱ����DMS������Ӧ�̷���
              bool flag = PubHelper.IsUsedDMSAPI();
              if (flag)
              {
                  try
                  {
                      PI08ImplService service = new PI08ImplService();
                      service.Url = PubHelper.GetAddress(service.Url);

                      supplierDto dto = new supplierDto();
                      List<supplierDto> list = new List<supplierDto>();

                      dto.suptCode = supplier.Code;
                      dto.suptName = supplier.Name;
                      dto.supShortName = supplier.ShortName;
                      if (supplier.ContactObjectKey != null)
                      {
                          if (supplier.ContactObject.PersonName != null)
                              dto.linkMan = supplier.ContactObject.PersonName.DisplayName;
                          dto.phone = supplier.ContactObject.DefaultPhoneNum;
                          dto.fax = supplier.ContactObject.DefaultFaxNum;
                          if (supplier.ContactObject.DefaultLocation!=null && supplier.ContactObject.DefaultLocation.PostalCode != null)
                              dto.zipCode = supplier.ContactObject.DefaultLocation.PostalCode.PostalCode;
                          if (supplier.ContactObject.DefaultLocation != null)
                              dto.address = supplier.ContactObject.DefaultLocation.Address1;
                      }
                      //string remark = "";
                      dto.actionType = 1;

                      list.Add(dto);

                      supplierDto s = service.receive(list.ToArray());
                      if (s != null && s.flag == 0)
                          throw new ApplicationException(s.errMsg);
                  }
                  catch (Exception e)
                  {

                      throw new ApplicationException("����DMS�ӿڴ���" + e.Message);
                  }


              }
            #endregion
        }
    }
    #endregion
    #region ��Ӧ��ɾ��
    public class SupplierDeleted : UFSoft.UBF.Eventing.IEventSubscriber
    {
        public void Notify(params object[] args)
        {

            #region ���¼�������ȡ�õ�ǰҵ��ʵ��

            //���¼�������ȡ�õ�ǰҵ��ʵ��
            if (args == null || args.Length == 0 || !(args[0] is UFSoft.UBF.Business.EntityEvent))
                return;
            BusinessEntity.EntityKey key = ((UFSoft.UBF.Business.EntityEvent)args[0]).EntityKey;
            if (key == null)
                return;
            Supplier supplier = key.GetEntity() as Supplier;
            //��Ӧ��ɾ��ʱ����DMSɾ����Ӧ�̷���
              bool flag = PubHelper.IsUsedDMSAPI();
              if (flag)
              {
                  try
                  {
                      PI08ImplService service = new PI08ImplService();
                      service.Url = PubHelper.GetAddress(service.Url);

                      supplierDto dto = new supplierDto();
                      List<supplierDto> list = new List<supplierDto>();

                      dto.suptCode = supplier.Code;
                      dto.suptName = supplier.Name;
                      dto.supShortName = supplier.ShortName;
                      if (supplier.ContactObjectKey != null)
                      {
                          if (supplier.ContactObject.PersonName != null)
                              dto.linkMan = supplier.ContactObject.PersonName.DisplayName;
                          dto.phone = supplier.ContactObject.DefaultPhoneNum;
                          dto.fax = supplier.ContactObject.DefaultFaxNum;
                          if (supplier.ContactObject.DefaultLocation != null && supplier.ContactObject.DefaultLocation.PostalCode != null)
                              dto.zipCode = supplier.ContactObject.DefaultLocation.PostalCode.PostalCode;
                          if (supplier.ContactObject.DefaultLocation != null)
                              dto.address = supplier.ContactObject.DefaultLocation.Address1;
                      }
                      //string remark = "";
                      dto.actionType = 3;

                      list.Add(dto);


                      supplierDto s = service.receive(list.ToArray());
                      if (s != null && s.flag == 0)
                          throw new ApplicationException(s.errMsg);
                  }
                  catch (Exception e)
                  {

                      throw new ApplicationException("����DMS�ӿڴ���" + e.Message);
                  }
              }

            #endregion
        }
    }
    #endregion
    #region ��Ӧ���޸�
    public class SupplierUpdated : UFSoft.UBF.Eventing.IEventSubscriber
    {
        public void Notify(params object[] args)
        {

            #region ���¼�������ȡ�õ�ǰҵ��ʵ��

            //���¼�������ȡ�õ�ǰҵ��ʵ��
            if (args == null || args.Length == 0 || !(args[0] is UFSoft.UBF.Business.EntityEvent))
                return;
            BusinessEntity.EntityKey key = ((UFSoft.UBF.Business.EntityEvent)args[0]).EntityKey;
            if (key == null)
                return;
            Supplier supplier = key.GetEntity() as Supplier;
            //��Ӧ���޸�ʱ����DMS�޸Ĺ�Ӧ�̷���
              bool flag = PubHelper.IsUsedDMSAPI();
              if (flag)
              {
                  try
                  {
                      PI08ImplService service = new PI08ImplService();
                      service.Url = PubHelper.GetAddress(service.Url);

                      supplierDto dto = new supplierDto();
                      List<supplierDto> list = new List<supplierDto>();

                      dto.suptCode = supplier.Code;
                      dto.suptName = supplier.Name;
                      dto.supShortName = supplier.ShortName;
                      if (supplier.ContactObjectKey != null)
                      {
                          if (supplier.ContactObject.PersonName != null)
                              dto.linkMan = supplier.ContactObject.PersonName.DisplayName;
                          dto.phone = supplier.ContactObject.DefaultPhoneNum;
                          dto.fax = supplier.ContactObject.DefaultFaxNum;
                          if (supplier.ContactObject.DefaultLocation != null && supplier.ContactObject.DefaultLocation.PostalCode != null)
                              dto.zipCode = supplier.ContactObject.DefaultLocation.PostalCode.PostalCode;
                          if (supplier.ContactObject.DefaultLocation != null)
                              dto.address = supplier.ContactObject.DefaultLocation.Address1;
                      }
                      //string remark = "";
                      dto.actionType = 2;

                      list.Add(dto);


                      supplierDto s = service.receive(list.ToArray());
                      if (s != null && s.flag == 0)
                          throw new ApplicationException(s.errMsg);
                  }
                  catch (Exception e)
                  {

                      throw new ApplicationException("����DMS�ӿڴ���" + e.Message);
                  }

              }

            #endregion
        }
    }
    #endregion
}
