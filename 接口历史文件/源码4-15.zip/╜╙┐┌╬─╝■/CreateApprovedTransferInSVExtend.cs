﻿namespace UFIDA.U9.Cust.HBDY.API.TransferInSV
{
	using System;
	using System.Collections.Generic;
	using System.Text; 
	using UFSoft.UBF.AopFrame;	
	using UFSoft.UBF.Util.Context;
    using UFIDA.U9.ISV.TransferInISV.Proxy;
    using UFIDA.U9.ISV.TransferInISV;
    using UFIDA.U9.Base;
    using UFIDA.U9.CBO.Pub.Controller;
    using UFSoft.UBF.Business;
    using UFIDA.U9.InvDoc.TransferIn;
    using UFIDA.U9.CBO.SCM.Item;
    using UFIDA.U9.CBO.SCM.Warehouse;
    using System.Transactions;

	/// <summary>
	/// CreateApprovedTransferInSV partial 
	/// </summary>	
	public partial class CreateApprovedTransferInSV 
	{	
		internal BaseStrategy Select()
		{
			return new CreateApprovedTransferInSVImpementStrategy();	
		}		
	}
	
	#region  implement strategy	
	/// <summary>
	/// Impement Implement
	/// 
	/// </summary>	
	internal partial class CreateApprovedTransferInSVImpementStrategy : BaseStrategy
	{
		public CreateApprovedTransferInSVImpementStrategy() { }

		public override object Do(object obj)
		{		
			
			CreateApprovedTransferInSV bpObj = (CreateApprovedTransferInSV)obj;

            List<TransferInResultDTO> result = new List<TransferInResultDTO>();
            TransferInResultDTO resultdto;

            try
            {
                #region 参数校验
                if (bpObj.TransferInLineDTOList == null || bpObj.TransferInLineDTOList.Count == 0)
                {
                    resultdto = new TransferInResultDTO();
                    resultdto.IsSuccess = false;
                    resultdto.ErrorInfo = "传入参数不可为空";
                    resultdto.Timestamp = DateTime.Now;
                    result.Add(resultdto);
                    return result;
                }
                //参数合法校验
                string errormessage = ValidateParamNullOrEmpty(bpObj);

                if (!string.IsNullOrEmpty(errormessage))
                {
                    resultdto = new TransferInResultDTO();
                    resultdto.IsSuccess = false;
                    resultdto.ErrorInfo = errormessage + "请检查传入参数";
                    resultdto.Timestamp = DateTime.Now;
                    result.Add(resultdto);
                    return result;
                }
                #endregion
                List<UFIDA.U9.CBO.Pub.Controller.CommonArchiveDataDTOData> transinidlist;

                using (UFSoft.UBF.Transactions.UBFTransactionScope trans1 = new UFSoft.UBF.Transactions.UBFTransactionScope(UFSoft.UBF.Transactions.TransactionOption.RequiresNew))
                {

                    #region 创建调入单
                    try
                    {
                        CommonCreateTransferInSVProxy proxy = new CommonCreateTransferInSVProxy();
                        proxy.TransferInDTOList = GetTransferInDTOList(bpObj);
                        transinidlist = proxy.Do();
                        //}
                        //catch (Exception e)
                        //{
                        //    resultdto = new TransferInResultDTO();
                        //    resultdto.IsSuccess = false;
                        //    resultdto.ErrorInfo = "生单失败：" + e.Message;
                        //    resultdto.Timestamp = DateTime.Now;
                        //    result.Add(resultdto);
                        //    return result;
                        //}

                        if (transinidlist == null || transinidlist.Count <= 0)
                        {
                            resultdto = new TransferInResultDTO();
                            resultdto.IsSuccess = false;
                            resultdto.ErrorInfo = "生单失败：没有生成调入单";
                            resultdto.Timestamp = DateTime.Now;
                            result.Add(resultdto);
                            return result;
                        }
                    #endregion

                    #region 审核调入单
                        //try
                        //{

                        TransferInBatchApproveSRVProxy approveproxy = new TransferInBatchApproveSRVProxy();
                        approveproxy.DocList = transinidlist;
                        approveproxy.ApprovedBy = Context.LoginUser;
                        approveproxy.ApprovedOn = DateTime.Now;
                        approveproxy.Do();

                        trans1.Commit();


                    }
                    catch (Exception e)
                    {

                        trans1.Rollback();

                        resultdto = new TransferInResultDTO();
                        resultdto.IsSuccess = false;
                        resultdto.ErrorInfo = "生单失败：" + e.Message;
                        resultdto.Timestamp = DateTime.Now;
                        result.Add(resultdto);

                        //throw new Exception(e.Message);

                        return result;
                    }

                        #endregion


                }

                foreach (CommonArchiveDataDTOData transin in transinidlist)
                {
                    TransferIn t = TransferIn.Finder.FindByID(transin.ID);
                    if (t != null)
                    {
                        resultdto = new TransferInResultDTO();
                        resultdto.IsSuccess = true;
                        resultdto.ErrorInfo = "生单成功";
                        resultdto.Timestamp = DateTime.Now;
                        resultdto.ERPDocNo = transin.Code;
                        resultdto.TransDocNo = t.DescFlexField.PrivateDescSeg4;
                        result.Add(resultdto);
                    }
                }

                return result;
            }
            catch (Exception e)
            {

                resultdto = new TransferInResultDTO();
                resultdto.IsSuccess = false;
                resultdto.ErrorInfo = e.Message;
                resultdto.Timestamp = DateTime.Now;
                result.Add(resultdto);
                return result;
            }
          

        }
        /// <summary>
        /// 传入参数非空校验
        /// </summary>
        /// <param name="bpObj"></param>
        private string ValidateParamNullOrEmpty(CreateApprovedTransferInSV bpObj)
        {

            #region 传入参数校验

            string errormessage = string.Empty;
                        
                foreach (TransInLineDTO linedto in bpObj.TransferInLineDTOList)
                {

                    if (linedto.OperationType <= 0)
                        errormessage += string.Format("[{0}]DMS移库单的[操作类型]不可为空,", linedto.TransDocNo);

                    //物料编号
                    if (string.IsNullOrEmpty(linedto.ItemMaster))
                        errormessage += string.Format("[{0}]DMS移库单的参数TtransInLines的[ERP料号]不可为空,", linedto.TransDocNo);
                    else
                    {
                        ItemMaster item = ItemMaster.Finder.Find(string.Format("Org={0} and Code='{1}'", Context.LoginOrg.ID.ToString(), linedto.ItemMaster));
                        if (item == null)
                            errormessage += string.Format("[{0}]DMS移库单的参数TtransInLines的[ERP料号({1})]在U9系统中找不到对应的料品档案,请同步,", linedto.TransDocNo,linedto.ItemMaster);
                    }

                    //调出存储地点
                    if (string.IsNullOrEmpty(linedto.WhOut))
                        errormessage += string.Format("[{0}]DMS移库单的参数TtransInLines的[调出存储地点]不可为空,", linedto.TransDocNo);
                    else
                    {
                        Warehouse whout = Warehouse.Finder.Find(string.Format("Org={0} and Code='{1}'", Context.LoginOrg.ID.ToString(), linedto.WhOut));
                        if (whout == null)
                            errormessage += string.Format("[{0}]DMS移库单的参数TtransInLines的[调出存储地点({1})]在U9系统中找不到对应的存储地点档案,请同步,", linedto.TransDocNo,linedto.WhOut);
                    }
                    //调入存储地点
                    if (string.IsNullOrEmpty(linedto.WhIn))
                        errormessage += string.Format("[{0}]DMS移库单的参数TtransInLines的[调入存储地点]不可为空,", linedto.TransDocNo);
                    else
                    {
                        Warehouse whin = Warehouse.Finder.Find(string.Format("Org={0} and Code='{1}'", Context.LoginOrg.ID.ToString(), linedto.WhIn));
                        if (whin == null)
                            errormessage += string.Format("[{0}]DMS移库单的参数TtransInLines的[调入存储地点({1})]在U9系统中找不到对应的存储地点档案,请同步,", linedto.TransDocNo,linedto.WhIn);
                    }

                    //数量
                    if (linedto.Number<=0)
                        errormessage += string.Format("[{0}]DMS移库单的参数TtransInLines的[数量]必须大于0,", linedto.TransDocNo);
                }


            return errormessage;
            #endregion


        }
        /// <summary>
        /// 得到调入单dto
        /// </summary>
        /// <param name="bpObj"></param>
        /// <returns></returns>
        private List<IC_TransferInDTOData> GetTransferInDTOList(CreateApprovedTransferInSV bpObj)
        {
            List<IC_TransferInDTOData> list = new List<IC_TransferInDTOData>();

            IC_TransferInDTOData transindto;

            Dictionary<string, List<TransInLineDTO>> dic = new Dictionary<string, List<TransInLineDTO>>();

            foreach(TransInLineDTO dtoline in bpObj.TransferInLineDTOList)
            {
                if (!dic.ContainsKey(dtoline.SpitOrderFlag))
                    dic.Add(dtoline.SpitOrderFlag, new List<TransInLineDTO>());

                dic[dtoline.SpitOrderFlag].Add(dtoline);
            }
           

            foreach (string key  in dic.Keys)
            {
                transindto = new IC_TransferInDTOData();
                
                //单据类型
                transindto.TransInDocType = new UFIDA.U9.CBO.Pub.Controller.CommonArchiveDataDTOData();
                if (dic[key][0].OperationType == 1)
                    transindto.TransInDocType.Code = "MoveWH";
                else if (dic[key][0].OperationType == 2)
                    transindto.TransInDocType.Code = "CarOutWH";

                transindto.CreatedBy = Context.LoginUser;
                transindto.CreatedOn = DateTime.Now;
                transindto.ModifiedBy = Context.LoginUser;
                transindto.ModifiedOn = DateTime.Now;

                //移库单号/DMS销售订单
                transindto.DescFlexField = new UFIDA.U9.Base.FlexField.DescFlexField.DescFlexSegmentsData();
                transindto.DescFlexField.PrivateDescSeg4 = dic[key][0].TransDocNo;

                transindto.TransInLines = new List<IC_TransInLineDTOData>();

                IC_TransInLineDTOData transinlinedto;
                IC_TransInSubLineDTOData sublinedto;
                foreach (TransInLineDTO linedto in dic[key])
                {
                    transinlinedto = new IC_TransInLineDTOData();

                    //料品
                    transinlinedto.ItemInfo = new UFIDA.U9.CBO.SCM.Item.ItemInfoData();
                    transinlinedto.ItemInfo.ItemCode = linedto.ItemMaster;

                    transinlinedto.TransInWh = new UFIDA.U9.CBO.Pub.Controller.CommonArchiveDataDTOData();
                    transinlinedto.TransInWh.Code = linedto.WhIn;
                    //存储类型
                    Warehouse whin = Warehouse.Finder.Find(string.Format("Org={0} and Code='{1}'", Context.LoginOrg.ID.ToString(), linedto.WhIn));
                    if (whin != null)
                        transinlinedto.StorageType = whin.StorageType.Value;
                    else
                        transinlinedto.StorageType = 4;

                    transinlinedto.StoreUOMQty = linedto.Number;

                    transinlinedto.CostCurrency = new UFIDA.U9.CBO.Pub.Controller.CommonArchiveDataDTOData();
                    transinlinedto.CostCurrency.Code = linedto.Currency;

                    transinlinedto.DescFlexSegments = new UFIDA.U9.Base.FlexField.DescFlexField.DescFlexSegmentsData();
                    transinlinedto.DescFlexSegments.PubDescSeg12 = linedto.VIN;

                    transinlinedto.Project = new CommonArchiveDataDTOData();
                    transinlinedto.Project.Code = linedto.TransDocNo;


                    transinlinedto.TransInSubLines = new List<IC_TransInSubLineDTOData>();
                    sublinedto = new IC_TransInSubLineDTOData();
                    sublinedto.TransOutWh = new UFIDA.U9.CBO.Pub.Controller.CommonArchiveDataDTOData();
                    sublinedto.TransOutWh.Code = linedto.WhOut;

                    sublinedto.Project = new CommonArchiveDataDTOData();
                    sublinedto.Project.Code = linedto.TransDocNo;

                   //存储类型
                    Warehouse whout = Warehouse.Finder.Find(string.Format("Org={0} and Code='{1}'", Context.LoginOrg.ID.ToString(), linedto.WhOut));
                    if (whout != null)
                        sublinedto.StorageType = whout.StorageType.Value;
                    else
                        sublinedto.StorageType = 4;


                    transinlinedto.TransInSubLines.Add(sublinedto);
                    transindto.TransInLines.Add(transinlinedto);

                }

               
                list.Add(transindto);
            }
            
           
            return list;
        }
	}

	#endregion
	
	
}