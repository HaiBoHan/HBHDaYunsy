using System;
using System.Collections.Generic;
using System.Text;
using UFSoft.UBF.Business;
using UFIDA.U9.SPR.SalePriceList;
using UFIDA.U9.Cust.HBDY.DaYunPlugIn.DMS_PI06;
using UFIDA.U9.CBO.SCM.Supplier;
using UFIDA.U9.Base;

namespace UFIDA.U9.Cust.HBDY.DaYunPlugIn
{
    #region ���ۼ۱�����
    public class SalePriceListInserted : UFSoft.UBF.Eventing.IEventSubscriber
    {
        public void Notify(params object[] args)
        {

            #region ���¼�������ȡ�õ�ǰҵ��ʵ��

            //���¼�������ȡ�õ�ǰҵ��ʵ��
            if (args == null || args.Length == 0 || !(args[0] is UFSoft.UBF.Business.EntityEvent))
                return;
            BusinessEntity.EntityKey key = ((UFSoft.UBF.Business.EntityEvent)args[0]).EntityKey;
            if (key == null)
                return;
            SalePriceList SalepriceList = key.GetEntity() as SalePriceList;
              bool flag = PubHelper.IsUsedDMSAPI();
              if (flag)
              {
                  PI06ImplService service = new PI06ImplService();
                  service.Url = PubHelper.GetAddress(service.Url);

                  partBaseDto linedto;
                  List<partBaseDto> lines = new List<partBaseDto>();

                  foreach (SalePriceLine line in SalepriceList.SalePriceLines)
                  {
                      //if (line.ItemInfo.ItemID.StockCategory.Code == "26")   //���������Ϊ���ۺ������
                      //{
                      if (line.Active == true && DateTime.Now >= line.FromDate && (DateTime.Now < line.ToDate || line.ToDate.ToString() == "9999.12.31"))
                      {
                          SupplierItem.EntityList supitemlist = SupplierItem.Finder.FindAll(string.Format("Org={0} and ItemInfo.ItemID={1} and Effective.IsEffective=1 and '{2}' between Effective.EffectiveDate and Effective.DisableDate", Context.LoginOrg.ID.ToString(), line.ItemInfo.ItemID.ID.ToString(), DateTime.Now.ToString()));
                          if (supitemlist != null && supitemlist.Count > 0)
                          {
                              foreach (SupplierItem i in supitemlist)
                              {
                                  linedto = new partBaseDto();

                                  linedto.suptCode = i.SupplierInfo.Supplier.Code;
                                  linedto.partCode = line.ItemInfo.ItemID.Code;
                                  linedto.partName = line.ItemInfo.ItemID.Name;
                                  if (line.ItemInfo.ItemID.InventoryUOM != null)
                                      linedto.unit = line.ItemInfo.ItemID.InventoryUOM.Name;
                                  if (line.ItemInfo.ItemID.PurchaseInfo != null)
                                      linedto.miniPack = Convert.ToInt32(line.ItemInfo.ItemID.PurchaseInfo.MinRcvQty);
                                  linedto.salePrice = float.Parse(line.Price.ToString());
                                  linedto.unitPrace = linedto.salePrice;
                                  linedto.isDanger = "0";
                                  linedto.isReturn = "1";
                                  linedto.isSale = "1";
                                  linedto.isFlag = "1";
                                  linedto.isEffective = line.Active.ToString();
                                  linedto.actionType = 1;

                                  lines.Add(linedto);
                              }
                          }
                          else
                          {
                              linedto = new partBaseDto();

                              //linedto.suptCode = string.Empty;
                              linedto.partCode = line.ItemInfo.ItemID.Code;
                              linedto.partName = line.ItemInfo.ItemID.Name;
                              if (line.ItemInfo.ItemID.InventoryUOM != null)
                                  linedto.unit = line.ItemInfo.ItemID.InventoryUOM.Name;
                              if (line.ItemInfo.ItemID.PurchaseInfo != null)
                                  linedto.miniPack = Convert.ToInt32(line.ItemInfo.ItemID.PurchaseInfo.MinRcvQty);
                              linedto.salePrice = float.Parse(line.Price.ToString());
                              linedto.unitPrace = linedto.salePrice;
                              linedto.isDanger = "0";
                              linedto.isReturn = "1";
                              linedto.isSale = "1";
                              linedto.isFlag = "1";
                              linedto.isEffective = line.Active.ToString();
                              linedto.actionType = 1;

                              lines.Add(linedto);
                          }
                      }

                      //}
                  }
                  try
                  {
                      if (lines.Count > 0)
                      {
                          partBaseDto d = service.receive(lines.ToArray());
                          if (d != null && d.flag == 0)
                              throw new ApplicationException(d.errMsg);
                      }

                  }
                  catch (Exception e)
                  {

                      throw new ApplicationException("����DMS�ӿڴ���" + e.Message);
                  }
              }
            #endregion
        }
    }
    #endregion
    #region ���ۼ۱�ɾ��
    public class SalePriceListDeleted : UFSoft.UBF.Eventing.IEventSubscriber
    {
        public void Notify(params object[] args)
        {

            #region ���¼�������ȡ�õ�ǰҵ��ʵ��

            //���¼�������ȡ�õ�ǰҵ��ʵ��
            if (args == null || args.Length == 0 || !(args[0] is UFSoft.UBF.Business.EntityEvent))
                return;
            BusinessEntity.EntityKey key = ((UFSoft.UBF.Business.EntityEvent)args[0]).EntityKey;
            if (key == null)
                return;
            SalePriceList SalepriceList = key.GetEntity() as SalePriceList;
              bool flag = PubHelper.IsUsedDMSAPI();
              if (flag)
              {
                  PI06ImplService service = new PI06ImplService();
                  service.Url = PubHelper.GetAddress(service.Url);

                  partBaseDto linedto;
                  List<partBaseDto> lines = new List<partBaseDto>();

                  foreach (SalePriceLine line in SalepriceList.SalePriceLines.DelLists)
                  {
                      //if (line.ItemInfo.ItemID.StockCategory.Code == "26")   //���������Ϊ���ۺ������
                      //{
                      linedto = new partBaseDto();
                      //if (line.ItemInfo.ItemID.PurchaseInfo != null && line.ItemInfo.ItemID.PurchaseInfo.SupplierKey != null)
                      //    linedto.suptCode = line.ItemInfo.ItemID.PurchaseInfo.Supplier.Code;

                      linedto.partCode = line.ItemInfo.ItemID.Code;
                      linedto.partName = line.ItemInfo.ItemID.Name;
                      if (line.ItemInfo.ItemID.InventoryUOM != null)
                          linedto.unit = line.ItemInfo.ItemID.InventoryUOM.Name;
                      if (line.ItemInfo.ItemID.PurchaseInfo != null)
                          linedto.miniPack = Convert.ToInt32(line.ItemInfo.ItemID.PurchaseInfo.MinRcvQty);
                      linedto.salePrice = float.Parse(line.Price.ToString());
                      linedto.unitPrace = linedto.salePrice;
                      linedto.isDanger = "0";
                      linedto.isReturn = "1";
                      linedto.isSale = "1";
                      linedto.isFlag = "1";
                      linedto.isEffective = line.Active.ToString();
                      linedto.actionType = 3;

                      lines.Add(linedto);
                      //}
                  }
                  try
                  {
                      if (lines.Count > 0)
                      {
                          partBaseDto t = service.receive(lines.ToArray());
                          if (t != null && t.flag == 0)
                              throw new ApplicationException(t.errMsg);
                      }

                  }
                  catch (Exception e)
                  {

                      throw new ApplicationException("����DMS�ӿڴ���" + e.Message);
                  }

              }
            #endregion
        }
    }
    #endregion
    #region ���ۼ۱��޸�
    public class SalePriceListUpdating : UFSoft.UBF.Eventing.IEventSubscriber
    {
        public void Notify(params object[] args)
        {

            #region ���¼�������ȡ�õ�ǰҵ��ʵ��

            //���¼�������ȡ�õ�ǰҵ��ʵ��
            if (args == null || args.Length == 0 || !(args[0] is UFSoft.UBF.Business.EntityEvent))
                return;
            BusinessEntity.EntityKey key = ((UFSoft.UBF.Business.EntityEvent)args[0]).EntityKey;
            if (key == null)
                return;
            SalePriceList SalepriceList = key.GetEntity() as SalePriceList;
              bool flag = PubHelper.IsUsedDMSAPI();
              if (flag)
              {
                  PI06ImplService service = new PI06ImplService();
                  service.Url = PubHelper.GetAddress(service.Url);

                  partBaseDto linedto;
                  List<partBaseDto> lines = new List<partBaseDto>();

                  foreach (SalePriceLine line in SalepriceList.SalePriceLines)
                  {
                      if (line.SysState != UFSoft.UBF.PL.Engine.ObjectState.Deleted)
                      {
                          if (line.SysState != UFSoft.UBF.PL.Engine.ObjectState.Inserted)
                          {
                              #region �޸�
                              if (line.OriginalData.Price != line.Price)   //���������Ϊ���ۺ������ ֻ�Ǽ۸�仯line.ItemInfo.ItemID.StockCategory.Code == "26" && 
                              {
                                  if (DateTime.Now >= line.FromDate && (DateTime.Now < line.ToDate || line.ToDate.ToString() == "9999.12.31"))
                                  {

                                      SupplierItem.EntityList supitemlist = SupplierItem.Finder.FindAll(string.Format("Org={0} and ItemInfo.ItemID={1} and Effective.IsEffective=1 and '{2}' between Effective.EffectiveDate and Effective.DisableDate", Context.LoginOrg.ID.ToString(), line.ItemInfo.ItemID.ID.ToString(), DateTime.Now.ToString()));
                                      if (supitemlist != null && supitemlist.Count > 0)
                                      {
                                          foreach (SupplierItem i in supitemlist)
                                          {
                                              linedto = new partBaseDto();

                                              linedto.suptCode = i.SupplierInfo.Supplier.Code;
                                              linedto.partCode = line.ItemInfo.ItemID.Code;
                                              linedto.partName = line.ItemInfo.ItemID.Name;
                                              if (line.ItemInfo.ItemID.InventoryUOM != null)
                                                  linedto.unit = line.ItemInfo.ItemID.InventoryUOM.Name;
                                              if (line.ItemInfo.ItemID.PurchaseInfo != null)
                                                  linedto.miniPack = Convert.ToInt32(line.ItemInfo.ItemID.PurchaseInfo.MinRcvQty);
                                              linedto.salePrice = float.Parse(line.Price.ToString());
                                              linedto.unitPrace = linedto.salePrice;
                                              linedto.isDanger = "0";
                                              linedto.isReturn = "1";
                                              linedto.isSale = "1";
                                              linedto.isFlag = "1";
                                              linedto.isEffective = line.Active.ToString();
                                              linedto.actionType = 2;

                                              lines.Add(linedto);
                                          }
                                      }
                                      else
                                      {
                                          linedto = new partBaseDto();

                                          //linedto.suptCode = string.Empty;
                                          linedto.partCode = line.ItemInfo.ItemID.Code;
                                          linedto.partName = line.ItemInfo.ItemID.Name;
                                          if (line.ItemInfo.ItemID.InventoryUOM != null)
                                              linedto.unit = line.ItemInfo.ItemID.InventoryUOM.Name;
                                          if (line.ItemInfo.ItemID.PurchaseInfo != null)
                                              linedto.miniPack = Convert.ToInt32(line.ItemInfo.ItemID.PurchaseInfo.MinRcvQty);
                                          linedto.salePrice = float.Parse(line.Price.ToString());
                                          linedto.unitPrace = linedto.salePrice;
                                          linedto.isDanger = "0";
                                          linedto.isReturn = "1";
                                          linedto.isSale = "1";
                                          linedto.isFlag = "1";
                                          linedto.isEffective = line.Active.ToString();
                                          linedto.actionType = 2;

                                          lines.Add(linedto);
                                      }
                                  }
                              }
                              #endregion

                          }
                          else
                          {
                              #region ����
                              //if (line.ItemInfo.ItemID.StockCategory.Code == "26")   //���������Ϊ���ۺ������
                              //{
                              if (line.Active == true && DateTime.Now >= line.FromDate && (DateTime.Now < line.ToDate || line.ToDate.ToString() == "9999.12.31"))
                              {
                                  SupplierItem.EntityList supitemlist = SupplierItem.Finder.FindAll(string.Format("Org={0} and ItemInfo.ItemID={1} and Effective.IsEffective=1 and '{2}' between Effective.EffectiveDate and Effective.DisableDate", Context.LoginOrg.ID.ToString(), line.ItemInfo.ItemID.ID.ToString(), DateTime.Now.ToString()));
                                  if (supitemlist != null && supitemlist.Count > 0)
                                  {
                                      foreach (SupplierItem i in supitemlist)
                                      {
                                          linedto = new partBaseDto();

                                          linedto.suptCode = i.SupplierInfo.Supplier.Code;
                                          linedto.partCode = line.ItemInfo.ItemID.Code;
                                          linedto.partName = line.ItemInfo.ItemID.Name;
                                          if (line.ItemInfo.ItemID.InventoryUOM != null)
                                              linedto.unit = line.ItemInfo.ItemID.InventoryUOM.Name;
                                          if (line.ItemInfo.ItemID.PurchaseInfo != null)
                                              linedto.miniPack = Convert.ToInt32(line.ItemInfo.ItemID.PurchaseInfo.MinRcvQty);
                                          linedto.salePrice = float.Parse(line.Price.ToString());
                                          linedto.unitPrace = linedto.salePrice;
                                          linedto.isDanger = "0";
                                          linedto.isReturn = "1";
                                          linedto.isSale = "1";
                                          linedto.isFlag = "1";
                                          linedto.isEffective = line.Active.ToString();
                                          linedto.actionType = 1;

                                          lines.Add(linedto);
                                      }
                                  }
                                  else
                                  {
                                      linedto = new partBaseDto();

                                      //linedto.suptCode = string.Empty;
                                      linedto.partCode = line.ItemInfo.ItemID.Code;
                                      linedto.partName = line.ItemInfo.ItemID.Name;
                                      if (line.ItemInfo.ItemID.InventoryUOM != null)
                                          linedto.unit = line.ItemInfo.ItemID.InventoryUOM.Name;
                                      if (line.ItemInfo.ItemID.PurchaseInfo != null)
                                          linedto.miniPack = Convert.ToInt32(line.ItemInfo.ItemID.PurchaseInfo.MinRcvQty);
                                      linedto.salePrice = float.Parse(line.Price.ToString());
                                      linedto.unitPrace = linedto.salePrice;
                                      linedto.isDanger = "0";
                                      linedto.isReturn = "1";
                                      linedto.isSale = "1";
                                      linedto.isFlag = "1";
                                      linedto.isEffective = line.Active.ToString();
                                      linedto.actionType = 1;

                                      lines.Add(linedto);
                                  }
                              }

                              //}
                              #endregion
                          }
                      }

                  }
                  //ɾ��
                  foreach (SalePriceLine line in SalepriceList.SalePriceLines.DelLists)
                  {
                      //if (line.ItemInfo.ItemID.StockCategory.Code == "26")   //���������Ϊ���ۺ������
                      //{
                      linedto = new partBaseDto();
                      //if (line.ItemInfo.ItemID.PurchaseInfo != null && line.ItemInfo.ItemID.PurchaseInfo.SupplierKey != null)
                      //    linedto.suptCode = line.ItemInfo.ItemID.PurchaseInfo.Supplier.Code;

                      linedto.partCode = line.ItemInfo.ItemID.Code;
                      linedto.partName = line.ItemInfo.ItemID.Name;
                      if (line.ItemInfo.ItemID.InventoryUOM != null)
                          linedto.unit = line.ItemInfo.ItemID.InventoryUOM.Name;
                      if (line.ItemInfo.ItemID.PurchaseInfo != null)
                          linedto.miniPack = Convert.ToInt32(line.ItemInfo.ItemID.PurchaseInfo.MinRcvQty);
                      linedto.salePrice = float.Parse(line.Price.ToString());
                      linedto.unitPrace = linedto.salePrice;
                      linedto.isDanger = "0";
                      linedto.isReturn = "1";
                      linedto.isSale = "1";
                      linedto.isFlag = "1";
                      linedto.isEffective = line.Active.ToString();
                      linedto.actionType = 3;

                      lines.Add(linedto);
                      //}
                  }
                  try
                  {
                      if (lines.Count > 0)
                      {
                          partBaseDto t = service.receive(lines.ToArray());
                          if (t != null && t.flag == 0)
                              throw new ApplicationException(t.errMsg);
                      }

                  }
                  catch (Exception e)
                  {

                      throw new ApplicationException("����DMS�ӿڴ���" + e.Message);
                  }


              }

            //if (SalepriceLine.ItemInfo.ItemID.InventoryUOM.Code == "26" && (SalepriceLine.OriginalData.ItemInfo.ItemID!=SalepriceLine.ItemInfo.ItemID || SalepriceLine.OriginalData.Price!=SalepriceLine.Price))   //���������Ϊ���ۺ������
            //{
            //    string suptCode = SalepriceLine.ItemInfo.ItemID.PurchaseInfo.Supplier.Code;
            //    string partCode = SalepriceLine.ItemInfo.ItemID.Code;
            //    string partName = SalepriceLine.ItemInfo.ItemID.Name;
            //    string unit = SalepriceLine.ItemInfo.ItemID.InventoryUOM.Name;
            //    decimal miniPack = SalepriceLine.ItemInfo.ItemID.PurchaseInfo.MinRcvQty;
            //    decimal salePrice = SalepriceLine.Price;
            //    //int isDanger = 0;
            //    //int isReturn = 0;
            //    //bool isSale = false;

            //    bool IsEffective = SalepriceLine.Active;
            //    int actionType = 2;
            //}

            #endregion
        }
    }
    #endregion
}
