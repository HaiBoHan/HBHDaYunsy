using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Xml;
using UFIDA.U9.Base.Profile.Proxy;
using UFIDA.U9.Base.Profile;

namespace UFIDA.U9.Cust.HBDY.DaYunPlugIn
{
   public class PubHelper
    {

        public static string GetAddress(string oldurl)
        {
            //string str = HttpContext.Current.Server.MapPath(@"/U9");
            string str = HttpRuntime.AppDomainAppPath.ToString();
            str += "\\bin\\DMSAPIServiceConfig.xml";
            XmlDocument doc = new XmlDocument();
            doc.Load(str);
            XmlNodeList list = doc.GetElementsByTagName("services");
            string newurl = list[0].Attributes["url"].Value;
         
            string strr = oldurl.Replace("http://", "");
            int t1 = strr.IndexOf("/");
            string h = strr.Substring(0, t1);
            string p = oldurl.Replace(h, newurl);
            return p;
        }
       /// <summary>
       /// �Ƿ����dms�ӿ�
       /// </summary>
       /// <returns></returns>
       public static bool IsUsedDMSAPI()
       {
           //string str = HttpContext.Current.Server.MapPath(@"/U9");
           //str += "\\bin\\DMSAPIServiceConfig.xml";
           //XmlDocument doc = new XmlDocument();
           //doc.Load(str);
           //XmlNodeList list = doc.GetElementsByTagName("IsUsedDMSAPI");
           //string value = list[0].Attributes["value"].Value;
           //if (value.ToLower() == "false")
           //    return false;
           //else
           //    return true;
           string returnvalue = string.Empty;
           GetProfileValueProxy bpObj = new GetProfileValueProxy();
           bpObj.ProfileCode = "IsUsedDMSAPI";
           PVDTOData pVTDOData = bpObj.Do();
           if (pVTDOData != null)
               returnvalue = pVTDOData.ProfileValue;
           if (returnvalue.ToLower() == "false")
               return false;
           else
               return true; ;
       }
    }
}
