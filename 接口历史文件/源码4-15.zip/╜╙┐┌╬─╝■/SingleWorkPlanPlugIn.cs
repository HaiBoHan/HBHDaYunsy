using System;
using System.Collections.Generic;
using System.Text;
using UFSoft.UBF.Business;
using COM.DaYun.MFG.SingleWorkPlanBE;
using UFIDA.U9.SM.SO;
using UFIDA.U9.Base;
using UFIDA.U9.Cust.HBDY.DaYunPlugIn.DMS_SI03;

namespace UFIDA.U9.Cust.HBDY.DaYunPlugIn
{
    #region ��̨��ҵ�ƻ�Created
    public class SingleWorkPlanCreated : UFSoft.UBF.Eventing.IEventSubscriber
    {
        public void Notify(params object[] args)
        {

            #region ���¼�������ȡ�õ�ǰҵ��ʵ��

            //���¼�������ȡ�õ�ǰҵ��ʵ��
            if (args == null || args.Length == 0 || !(args[0] is UFSoft.UBF.Business.EntityEvent))
                return;
            BusinessEntity.EntityKey key = ((UFSoft.UBF.Business.EntityEvent)args[0]).EntityKey;
            if (key == null)
                return;
            SingleWorkPlan Singleworkplan = key.GetEntity() as SingleWorkPlan;
            //��̨��ҵ�ƻ�����ʱ������DMS�ӿ�[���ó���״̬���ٽӿ�]

            try
            {
                SI03ImplService service = new SI03ImplService();
                service.Url = PubHelper.GetAddress(service.Url);

                vehicleInfoDto dto = new vehicleInfoDto();

                if (Singleworkplan.SrcDoc != null && Singleworkplan.SrcDoc.PLSKey != null && Singleworkplan.SrcDoc.PLS.ProjectKey != null)
                {
                    SOLine soline = SOLine.Finder.Find(string.Format("SO.Org={0} and Project={1}", Context.LoginOrg.ID.ToString(), Singleworkplan.SrcDoc.PLS.ProjectKey.ID.ToString()));
                    if (soline != null)
                    {
                        dto.dmsSaleNo = soline.SO.DescFlexField.PubDescSeg5;
                    }
                }
                dto.commissionNo = Singleworkplan.WorkCode;
                dto.vin = Singleworkplan.VINFinal;
                if (Singleworkplan.ItemMasterKey != null)
                {
                    dto.erpMaterialCode = Singleworkplan.ItemMaster.Code;
                }
                dto.flowingCode = Singleworkplan.VIN;
                dto.oldVin = string.Empty;
                dto.nodeStatus = Singleworkplan.PlanStatus.Value.ToString();
                //dto. string Timestamp = Singleworkplan.WorkDate.ToString();


              vehicleInfoDto resultdto=service.receive(dto);
              if (resultdto != null && resultdto.flag == 0)
                  throw new ApplicationException(resultdto.errMsg);
            }
            catch (Exception e)
            {

                throw new ApplicationException("����DMS�ӿڴ���" + e.Message);
            }
           
            #endregion
        }
    }
    #endregion
    #region ��̨��ҵ�ƻ�Updated
    public class SingleWorkPlanUpdated : UFSoft.UBF.Eventing.IEventSubscriber
    {
        public void Notify(params object[] args)
        {

            #region ���¼�������ȡ�õ�ǰҵ��ʵ��

            //���¼�������ȡ�õ�ǰҵ��ʵ��
            if (args == null || args.Length == 0 || !(args[0] is UFSoft.UBF.Business.EntityEvent))
                return;
            BusinessEntity.EntityKey key = ((UFSoft.UBF.Business.EntityEvent)args[0]).EntityKey;
            if (key == null)
                return;
            SingleWorkPlan Singleworkplan = key.GetEntity() as SingleWorkPlan;
            //��̨��ҵ�ƻ�����״̬�����仯ʱ������DMS�ӿ�[���ó���״̬���ٽӿ�]
            if ((Singleworkplan.OriginalData.PlanStatus != Singleworkplan.PlanStatus))
            {

                try
                {
                    SI03ImplService service = new SI03ImplService();
                    service.Url = PubHelper.GetAddress(service.Url);

                    vehicleInfoDto dto = new vehicleInfoDto();

                    if (Singleworkplan.SrcDoc != null && Singleworkplan.SrcDoc.PLSKey != null && Singleworkplan.SrcDoc.PLS.ProjectKey != null)
                    {
                        SOLine soline = SOLine.Finder.Find(string.Format("SO.Org={0} and Project={1}", Context.LoginOrg.ID.ToString(), Singleworkplan.SrcDoc.PLS.ProjectKey.ID.ToString()));
                        if (soline != null)
                        {
                            dto.dmsSaleNo = soline.SO.DescFlexField.PubDescSeg5;
                        }
                        
                    }
                    dto.commissionNo = Singleworkplan.WorkCode;
                    dto.vin = Singleworkplan.VINFinal;
                    if (Singleworkplan.ItemMasterKey != null)
                    {
                        dto.erpMaterialCode = Singleworkplan.ItemMaster.Code;
                    }
                    dto.flowingCode = Singleworkplan.VIN;
                    dto.oldVin = string.Empty;
                    dto.nodeStatus = Singleworkplan.PlanStatus.Value.ToString();
                    //dto. string Timestamp = Singleworkplan.WorkDate.ToString();


                    vehicleInfoDto resultdto = service.receive(dto);
                    if (resultdto != null && resultdto.flag == 0)
                        throw new ApplicationException(resultdto.errMsg);

                }
                catch (Exception e)
                {

                    throw new ApplicationException("����DMS�ӿڴ���" + e.Message);
                }
           
            }


            #endregion
        }
    }
    #endregion
}
