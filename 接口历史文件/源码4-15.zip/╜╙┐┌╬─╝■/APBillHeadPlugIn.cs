using System;
using System.Collections.Generic;
using System.Text;
using UFSoft.UBF.Business;
using UFIDA.U9.AP.APBill;
using UFIDA.U9.CBO.FI.Enums;
using UFIDA.U9.SM.RMA;
using UFIDA.U9.Cust.HBDY.DaYunPlugIn.DMS_SI05;

namespace UFIDA.U9.Cust.HBDY.DaYunPlugIn
{
    #region Ӧ����Updated
    public class APBillHeadUpdated : UFSoft.UBF.Eventing.IEventSubscriber
    {
        public void Notify(params object[] args)
        {

            #region ���¼�������ȡ�õ�ǰҵ��ʵ��

            //���¼�������ȡ�õ�ǰҵ��ʵ��
            if (args == null || args.Length == 0 || !(args[0] is UFSoft.UBF.Business.EntityEvent))
                return;
            BusinessEntity.EntityKey key = ((UFSoft.UBF.Business.EntityEvent)args[0]).EntityKey;
            if (key == null)
                return;
            APBillHead APbillhead = key.GetEntity() as APBillHead;
            //Ӧ�����ʱ�����ۿ���Ϣ���á��ʽ�ͬ���ӿڡ���DMS
            if (APbillhead.OriginalData.DocStatus == BillStatusEnum.Approving && APbillhead.DocStatus == BillStatusEnum.Approved)
            {
                SI05ImplService service = new SI05ImplService();
                accountReturnDto dto;

                foreach (APBillLine line in APbillhead.APBillLines)
                {
                    if (line.SrcDocType == APBillSrcDocTypeEnum.RMA && line.SrcBillLineID > 0)
                    {
                        RMALine srcline = RMALine.Finder.FindByID(line.SrcBillLineID);
                        if (srcline != null)
                        {
                            dto = new accountReturnDto();

                            dto.dealerCode = srcline.RMA.Customer.Customer.Code;

                            dto.DMSShipNo = srcline.RMA.DescFlexField.PrivateDescSeg1;
                            dto.dmsSaleNo = srcline.RMA.DescFlexField.PubDescSeg5;
                            dto.earnestMoney = srcline.RMA.DescFlexField.PubDescSeg13;
                            dto.deposit = srcline.RMA.DescFlexField.PubDescSeg21;
                            dto.shipMoney= srcline.RMA.DescFlexField.PubDescSeg14;
                           
                            if (srcline.RMA.Customer.Customer.CustomerCategoryKey != null)
                            {
                                dto.customerType = srcline.RMA.Customer.Customer.CustomerCategory.Code;
                            }
                            dto.vin = srcline.RMA.DescFlexField.PubDescSeg12;
                            dto.amount = double.Parse((line.APOCMoney.NonTax + line.APOCMoney.GoodsTax).ToString());
                            dto.operaTionType = "1";
                            try
                            {
                              accountReturnDto c=service.receive(dto);
                              if (c!=null && c.flag == 0)
                                  throw new ApplicationException(c.errMsg);
                            }
                            catch (Exception e)
                            {

                                throw new ApplicationException("����DMS�ӿڴ���" + e.Message);
                            }
                        }
                    }
                }

            }


            #endregion
        }
    }
    #endregion
}
