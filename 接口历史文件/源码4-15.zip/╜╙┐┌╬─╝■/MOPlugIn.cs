using System;
using System.Collections.Generic;
using System.Text;
using UFSoft.UBF.Business;
using UFIDA.U9.MO.Enums;
using UFIDA.U9.Cust.HBDY.DaYunPlugIn.DMS_SI09;

namespace UFIDA.U9.Cust.HBDY.DaYunPlugIn
{
    #region ��������Updated
    public class MOUpdated : UFSoft.UBF.Eventing.IEventSubscriber
    {
        public void Notify(params object[] args)
        {

            #region ���¼�������ȡ�õ�ǰҵ��ʵ��

            //���¼�������ȡ�õ�ǰҵ��ʵ��
            if (args == null || args.Length == 0 || !(args[0] is UFSoft.UBF.Business.EntityEvent))
                return;
            BusinessEntity.EntityKey key = ((UFSoft.UBF.Business.EntityEvent)args[0]).EntityKey;
            if (key == null)
                return;
            UFIDA.U9.MO.MO.MO mo = key.GetEntity() as UFIDA.U9.MO.MO.MO;
              bool flag = PubHelper.IsUsedDMSAPI();
              if (flag)
              {
                  //����������������
                  if (mo.MODocType != null && mo.MODocType.Code == "MO02" && mo.OriginalData.DocState == MOStateEnum.Approved && mo.DocState == MOStateEnum.Released)
                  {
                      try
                      {
                          SI09ImplService service = new SI09ImplService();
                          service.Url = PubHelper.GetAddress(service.Url);

                          vehicleChangeInfoDto dto = new vehicleChangeInfoDto();
                          dto.vin = mo.DescFlexField.PubDescSeg12;
                          //string MODocNo = "";
                          dto.docStatus = 5;

                          vehicleChangeInfoDto d = service.receive(dto);
                          if (d != null && d.flag == 0)
                              throw new ApplicationException(d.errMsg);
                      }
                      catch (Exception e)
                      {

                          throw new ApplicationException("����DMS�ӿڴ���" + e.Message);
                      }


                  }

              }

            #endregion
        }
    }
    #endregion
}
